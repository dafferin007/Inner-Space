/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Heart, Sparkles, Smile, MessageCircle, Send, Check, PhoneCall, 
  Settings, User, Flame, Leaf, HelpCircle, Shield, Volume2, VolumeX,
  Compass, Users, AlertCircle, RefreshCw, Layers, ArrowLeftRight, ChevronRight,
  UserCheck, Smartphone, X
} from "lucide-react";
import { 
  AppScreen, THEMES, ThemePreset, AESTHETIC_AVATARS, CREATIVE_NAMES, 
  ScreamThought, ChatMessage, JournalEntry 
} from "./types";

// Import modular screens
import BreathingGame from "./components/BreathingGame";
import ScreamOut from "./components/ScreamOut";
import HearOut from "./components/HearOut";
import TherapyBooking from "./components/TherapyBooking";
import MoodJournal from "./components/MoodJournal";
import EmotionalRooms from "./components/EmotionalRooms";

export default function App() {
  // 1. Core State
  const [currentScreen, setCurrentScreen] = useState<AppScreen>(AppScreen.Splash);
  const [activeTheme, setActiveTheme] = useState<ThemePreset>("peach");
  const [username, setUsername] = useState("sleepy_ghost");
  const [selectedAvatarId, setSelectedAvatarId] = useState("glowing-mask");
  
  // Game state & statistics
  const [streak, setStreak] = useState(3);
  const [plantGrowth, setPlantGrowth] = useState(40); // 0 to 100%
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([
    {
      id: "j-1",
      date: "May 27, 2026",
      moodLevel: 4,
      sticker: "🌿",
      note: "Went for a slow walk under the cedar trees. Left my phone on the desk and just smelled the soft pine bark. Felt extremely light.",
      doodleDataUrl: ""
    }
  ]);

  // Onboarding mood selection
  const [selectedMoods, setSelectedMoods] = useState<string[]>([]);
  const [customAuraColor, setCustomAuraColor] = useState("linear-gradient(135deg, #FFD1BA 0%, #E8B4B8 100%)");
  const [auraDescription, setAuraDescription] = useState("A soft peach-pink dawn mist, reflecting deep tenderness and a seeking loop for comforting presence.");
  const [aiWellnessTips, setAiWellnessTips] = useState<string[]>([
    "Sip half a cup of warm chamomile, appreciating the vapor rising.",
    "Breathe gently using the 4-7-8 rhythm, centering your pacing.",
    "Whisper: 'I am allowed to rest. I am completely safe in this pause.'"
  ]);
  const [isLoadingAura, setIsLoadingAura] = useState(false);

  // Scream out community seed data
  const [screams, setScreams] = useState<ScreamThought[]>([
    { 
      id: "sc-1", 
      text: "Sometimes the silence in my room gets so loud it starts ringing. I just want to know that someone else is staring at the dusk sky too.", 
      screamType: "text", 
      reactions: { youMatter: 14, sendingWarmth: 22, iHearYou: 18, stayWithUs: 9 }, 
      timestamp: "3m ago", 
      username: "anonymous_petal", 
      avatarId: "dreamy-flower" 
    },
    { 
      id: "sc-2", 
      text: "Completely overwhelmed by work deadlines. I feel like an empty vessel being forced to carry heavy oceans. Running on sheer dust.", 
      screamType: "bubble", 
      reactions: { youMatter: 9, sendingWarmth: 15, iHearYou: 12, stayWithUs: 6 }, 
      timestamp: "12m ago", 
      username: "tired_river", 
      avatarId: "cloud-spirit",
      isCustomBg: true
    }
  ]);

  // AI Counselor chat panel states
  const [isCompanionOpen, setIsCompanionOpen] = useState(false);
  const [companionChat, setCompanionChat] = useState<ChatMessage[]>([
    { id: "comp-0", sender: "counselor", text: "Hello dear traveler. I am Cosmo, your AI comforting companion. Treat this space as a warm fireplace. What is weighing heavily on your thoughts today?", timestamp: "Now" }
  ]);
  const [companionInput, setCompanionInput] = useState("");
  const [isCompanionLoading, setIsCompanionLoading] = useState(false);

  // Sound and profile states
  const [isAmbientPlaying, setIsAmbientPlaying] = useState(false);
  const [bookedTherapistText, setBookedTherapistText] = useState("");
  const [bookedNotification, setBookedNotification] = useState<string | null>(null);

  // SVG background helpers for avatars
  const currentThemeProps = THEMES[activeTheme];

  // Call backend to fetch AI generated comfort suggestions & aura description
  const handleMoodSubmit = async () => {
    if (selectedMoods.length === 0) {
      setCurrentScreen(AppScreen.Home);
      return;
    }

    setIsLoadingAura(true);
    try {
      const res = await fetch("/api/generate-aura", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ primaryMoods: selectedMoods })
      });
      const data = await res.json();
      
      if (data.auraColor) setCustomAuraColor(data.auraColor);
      if (data.auraDescription) setAuraDescription(data.auraDescription);
      if (data.guidance) setAiWellnessTips(data.guidance);
      
    } catch (e) {
      console.warn("Aura fetching failed, utilizing graceful local fallback.", e);
    } finally {
      setIsLoadingAura(false);
      setCurrentScreen(AppScreen.Home);
    }
  };

  // Add custom user screams
  const handleAddScream = (text: string) => {
    const newScream: ScreamThought = {
      id: `usr-sc-${Date.now()}`,
      text: text,
      screamType: "text",
      reactions: { youMatter: 1, sendingWarmth: 1, iHearYou: 1, stayWithUs: 0 },
      timestamp: "Just now",
      username: "anonymous_spirit",
      avatarId: selectedAvatarId
    };
    setScreams(prev => [newScream, ...prev]);
  };

  // React to a scream
  const handleScreamReaction = (screamId: string, reactionType: string) => {
    setScreams(prev =>
      prev.map(sc => {
        if (sc.id === screamId) {
          const currentCount = sc.reactions[reactionType] || 0;
          return {
            ...sc,
            reactions: {
              ...sc.reactions,
              [reactionType]: currentCount + 1
            }
          };
        }
        return sc;
      })
    );
  };

  // Professional therapy booking confirmation
  const handleBookTherapist = (therapistName: string, date: string, time: string) => {
    setBookedTherapistText(`${therapistName} (${date} at ${time})`);
    setBookedNotification(`Sanctuary scheduled with ${therapistName}`);
    setTimeout(() => setBookedNotification(null), 4000);
  };

  // Add journal keepsake
  const handleAddJournal = (note: string, sticker: string, mood: number, doodleUrl?: string) => {
    const newEntry: JournalEntry = {
      id: `usr-j-${Date.now()}`,
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      moodLevel: mood,
      sticker: sticker,
      note: note,
      doodleDataUrl: doodleUrl
    };
    setJournalEntries(prev => [newEntry, ...prev]);
    
    // Plant growth reward logic based on journaling!
    setPlantGrowth(prev => Math.min(prev + 15, 100));
  };

  // AI Comfort Companion Cosmo messaging endpoint integration
  const handleSendCompanionMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companionInput.trim()) return;

    const userMsg: ChatMessage = {
      id: `usr-comp-${Date.now()}`,
      sender: "user",
      text: companionInput,
      timestamp: "Just now"
    };

    setCompanionChat(prev => [...prev, userMsg]);
    const originalInput = companionInput;
    setCompanionInput("");
    setIsCompanionLoading(true);

    try {
      // Map history turns inside backend schema formats
      const conversationHistory = companionChat
        .filter(c => c.sender !== "system")
        .map(c => ({
          role: c.sender === "user" ? "user" : "model",
          text: c.text
        }));

      const response = await fetch("/api/companion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: originalInput, history: conversationHistory })
      });
      const data = await response.json();

      const botMsg: ChatMessage = {
        id: `bot-comp-${Date.now()}`,
        sender: "counselor",
        text: data.text || "I am sitting quietly beside you. Breathe with me.",
        timestamp: "Just now"
      };
      setCompanionChat(prev => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      const errMsg: ChatMessage = {
        id: `bot-err-${Date.now()}`,
        sender: "counselor",
        text: "I felt a subtle silence in our link, but I am still right here, holding warm space for your presence. How else can I guide you?",
        timestamp: "Just now"
      };
      setCompanionChat(prev => [...prev, errMsg]);
    } finally {
      setIsCompanionLoading(false);
    }
  };

  // Cycle suggested random names
  const handleRandomizeName = () => {
    const randomName = CREATIVE_NAMES[Math.floor(Math.random() * CREATIVE_NAMES.length)];
    setUsername(randomName);
  };

  const currentThemeClass = currentThemeProps.bgColor;
  const currentAvatarInfo = AESTHETIC_AVATARS.find(av => av.id === selectedAvatarId) || AESTHETIC_AVATARS[0];
  const isMidnight = currentThemeProps.id === "midnight";

  return (
    <div className={`min-h-screen flex flex-col font-sans relative overflow-x-hidden antialiased transition-colors duration-500 pb-10 ${
      isMidnight 
        ? "bg-[#0E1220] text-slate-100" 
        : currentThemeProps.id === "lavender"
        ? "bg-[#F2EDFF] text-[#3D315B]"
        : currentThemeProps.id === "sage"
        ? "bg-[#F1F7F4] text-[#2E3D30]"
        : currentThemeProps.id === "cream"
        ? "bg-[#FCFAF2] text-[#4A3B2C]"
        : currentThemeProps.id === "sunset"
        ? "bg-[#FFF2E0] text-[#6B371F]"
        : "bg-[#FFF0ED] text-[#4A3F3D]"
    }`}>
      
      {/* Background radial gradient layers */}
      <div className={`absolute top-0 left-0 w-full h-[600px] pointer-events-none z-0 opacity-40 blur-3xl transition-opacity duration-500 bg-radial ${
        isMidnight 
          ? "from-cyan-500/10 via-transparent to-transparent" 
          : "from-[#FFD1CC]/40 via-transparent to-transparent"
      }`} />
      <div className={`absolute -bottom-40 -right-40 w-[600px] h-[600px] pointer-events-none z-0 opacity-45 blur-3xl transition-opacity duration-500 bg-radial ${
        isMidnight 
          ? "from-violet-500/10 via-transparent to-transparent" 
          : "from-[#FFB7B2]/30 via-transparent to-transparent"
      }`} />

      {/* Dynamic Global Audio Indicator */}
      {isAmbientPlaying && (
        <div className={`fixed bottom-4 right-4 border px-3.5 py-2 rounded-full z-50 text-[10px] font-mono flex items-center gap-2 shadow-sm scale-95 transition-all duration-300 ${
          isMidnight 
            ? "bg-slate-900/90 border-slate-800 text-[#0EA5E9]" 
            : "bg-white/80 border-stone-200/50 text-[#6D5A57] backdrop-blur-md"
        }`}>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>🔉 Binaural Beats Active</span>
        </div>
      )}

      {/* Booking schedule global banner notification */}
      {bookedNotification && (
        <div className={`fixed top-4 right-4 rounded-2xl shadow-md z-50 text-xs text-left max-w-xs animate-slide-in p-4 border ${
          isMidnight 
            ? "bg-emerald-950 border-emerald-800/60 text-emerald-300" 
            : "bg-white/90 border-emerald-100 text-[#2D5A41] backdrop-blur-md"
        }`}>
          <div className="flex gap-2">
            <Shield className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block">Sanctuary Booked</span>
              <p className="text-[10px] leading-normal opacity-90 mt-0.5">
                {bookedNotification}. A private live session is queued.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* PRIMARY TWO-COLUMN LAYOUT FRAME */}
      <div className="max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8 flex-1 flex flex-col md:flex-row gap-8 items-center z-10 relative">
        
        {/* LEFT COLUMN: BRANDING AND PRESENTER PANEL */}
        <div className="flex-1 w-full max-w-lg text-left self-start flex flex-col gap-6 py-4">
          <div className="flex items-center gap-2">
            <span className={`w-8 h-8 rounded-full flex items-center justify-center shadow-xs transition-colors ${
              isMidnight 
                ? "bg-gradient-to-tr from-cyan-500 to-indigo-500" 
                : "bg-[#FFD1CC] border border-white"
            }`}>
              <Heart className={`w-4 h-4 ${isMidnight ? "text-white" : "text-[#6D5A57] fill-[#6D5A57]/10"}`} />
            </span>
            <span className={`text-2xl font-serif italic tracking-tight ${isMidnight ? "text-white" : "text-[#6D5A57]"}`}>InnerSpace</span>
            <span className={`text-[8px] px-2.5 py-0.5 rounded-full font-mono font-bold tracking-wider uppercase ml-1 border ${
              isMidnight 
                ? "bg-cyan-500/10 border-cyan-500/20 text-cyan-400" 
                : "bg-white/60 border-white text-[#6D5A57]"
            }`}>
              Bento Showcase
            </span>
          </div>

          <div>
            <span className="text-[10px] font-mono tracking-wider uppercase opacity-65 block mb-1">Welcome to security</span>
            <h1 className={`text-4xl font-serif italic text-left tracking-tight leading-tight ${isMidnight ? "text-white" : "text-[#6D5A57]"}`}>
              A deeply aesthetic <br/>
              <span className="font-sans font-bold not-italic text-2xl tracking-tight text-stone-800 block mt-1.5 opacity-90">
                emotional sanctuary
              </span>
            </h1>
            
            <p className={`text-xs md:text-sm leading-relaxed mt-4 ${isMidnight ? "text-slate-400" : "text-[#8E7D7A]"}`}>
              InnerSpace is designed for individuals seeking solace from depression, anxiety, loneliness, or emotional burnout. It replaces traditional clinical profiles with dreamy, anonymous custom identities, cozy sensory visual animations, and real-time private therapeutic support channels.
            </p>
          </div>

          {/* DYNAMIC SCREEN NAVIGATION PRESET LIST */}
          <div className={`p-6 rounded-[32px] border flex flex-col gap-4 shadow-xs backdrop-blur-xl transition-all ${
            isMidnight 
              ? "bg-slate-900/40 border-white/5 text-slate-200" 
              : "bg-white/35 border-white text-[#4A3F3D]"
          }`}>
            <div className="flex justify-between items-center pb-2.5 border-b border-black/5">
              <span className={`text-xs font-serif italic flex items-center gap-1.5 ${isMidnight ? "text-slate-200" : "text-[#6D5A57]"}`}>
                <Layers className="w-4 h-4" />
                Case Study: 12 Sanctuary Screens
              </span>
              <span className="text-[9px] opacity-60 uppercase font-mono tracking-wider font-bold">Teleport instantly</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                { s: AppScreen.Splash, label: "1. Splash Intro Screen", icon: "🌌" },
                { s: AppScreen.Auth, label: "2. Creative Identity SignUp", icon: "👤" },
                { s: AppScreen.MoodOnboarding, label: "3. Mood Wheel Onboarding", icon: "🎡" },
                { s: AppScreen.Home, label: "4. Home Bento Dashboard", icon: "🏠" },
                { s: AppScreen.HearOut, label: "5. Hear Out Directory", icon: "👂" },
                { s: AppScreen.ScreamOut, label: "6. Scream Out Outlets", icon: "🌩️" },
                { s: AppScreen.UserProfileCustomization, label: "7. User Persona Creator", icon: "🎨" },
                { s: AppScreen.TherapyBooking, label: "8. Therapist Booking", icon: "👩‍⚕️" },
                { s: AppScreen.EmotionalRooms, label: "9. Group Emotional Rooms", icon: "🕯️" },
                { s: AppScreen.MoodJournal, label: "10. Mood Doodle Journal", icon: "📓" },
                { s: AppScreen.MiniGames, label: "11. Healing Mini Games", icon: "🎮" },
                { s: AppScreen.Settings, label: "12. Themes & Settings", icon: "⚙️" },
              ].map((item) => (
                <button
                  key={item.s}
                  onClick={() => {
                    setCurrentScreen(item.s);
                  }}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-xl border transition-all text-[11px] font-medium text-left ${
                    currentScreen === item.s 
                      ? (isMidnight ? "bg-slate-800 border-white/20 text-white shadow-xs" : "bg-white/60 border-white text-[#6D5A57] shadow-xs font-semibold") 
                      : (isMidnight ? "bg-slate-900/20 border-transparent text-slate-400 hover:text-white" : "bg-white/10 border-transparent text-[#8E7D7A] hover:bg-white/35 hover:text-stone-800")
                  }`}
                >
                  <span className="text-xs">{item.icon}</span>
                  <span className="truncate">{item.label}</span>
                </button>
              ))}
            </div>

            <div className={`mt-1 flex items-center gap-2.5 p-3.5 rounded-2xl text-left border ${
              isMidnight 
                ? "bg-slate-900/20 border-slate-800 text-slate-300" 
                : "bg-[#FFF0ED]/60 border-white text-[#8E7D7A]"
            }`}>
              <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-ping shrink-0" />
              <p className="text-[10px] leading-normal opacity-85">
                Active simulated chat connects directly with the live listener room inside screen 5 (Hear Out anonymous feed) and custom group streams on screen 9.
              </p>
            </div>
          </div>

          {/* DYNAMIC BACKEND STATE LOG INSPECTOR */}
          <div className={`p-4.5 rounded-[32px] border ${
            isMidnight 
              ? "bg-slate-900/30 border-white/5" 
              : "bg-white/35 border-white"
          }`}>
            <span className={`text-[9px] uppercase font-mono font-bold tracking-wider block mb-2.5 text-left ${
              isMidnight ? "text-slate-400" : "text-[#8E7D7A]"
            }`}>
              📱 Registered Workspace Parameters (Persisted local states):
            </span>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className={`p-2.5 rounded-2xl border ${
                isMidnight ? "bg-slate-950/60 border-slate-800 text-stone-200" : "bg-white/40 border-white/50 text-stone-700"
              }`}>
                <span className="text-[9px] opacity-60 block font-sans text-stone-500">Aesthetic Username</span>
                <strong className={`font-mono ${isMidnight ? "text-cyan-400" : "text-[#6D5A57]"}`}>@{username}</strong>
              </div>
              <div className={`p-2.5 rounded-2xl border ${
                isMidnight ? "bg-slate-950/60 border-slate-800 text-stone-200" : "bg-white/40 border-white/50 text-stone-700"
              }`}>
                <span className="text-[9px] opacity-60 block font-sans text-stone-500">Avatar Spirit</span>
                <strong className={isMidnight ? "text-violet-400" : "text-[#6D5A57]"}>{currentAvatarInfo.name}</strong>
              </div>
              <div className={`p-2.5 rounded-2xl border ${
                isMidnight ? "bg-slate-950/60 border-slate-800 text-stone-200" : "bg-white/40 border-white/50 text-stone-700"
              }`}>
                <span className="text-[9px] opacity-65 block font-sans text-stone-500">Healing Daily Streak</span>
                <strong className="text-orange-400 flex items-center gap-1 font-mono">
                  <Flame className="w-3.5 h-3.5 fill-current" />
                  {streak} days
                </strong>
              </div>
              <div className={`p-2.5 rounded-2xl border ${
                isMidnight ? "bg-slate-950/60 border-slate-800 text-stone-200" : "bg-white/40 border-white/50 text-stone-700"
              }`}>
                <span className="text-[9px] opacity-60 block font-sans text-stone-500">Doodles logged</span>
                <strong className={isMidnight ? "text-cyan-300" : "text-[#6D5A57] font-mono"}>{journalEntries.length} logged</strong>
              </div>
            </div>
          </div>

          {/* Urgent crisis contacts reference support block */}
          <div className={`rounded-[32px] border p-5 flex gap-3 text-left ${
            isMidnight 
              ? "bg-red-950/20 border-red-900/30 text-slate-300" 
              : "bg-white/50 border-white text-[#4A3F3D] shadow-xs"
          }`}>
            <Shield className={`w-5 h-5 shrink-0 mt-0.5 ${isMidnight ? "text-rose-500" : "text-[#F27D26]"}`} />
            <div>
              <span className={`text-xs font-semibold block ${isMidnight ? "text-slate-300" : "text-[#6D5A57]"}`}>Urgent Safety Assurance Line</span>
              <p className={`text-[10px] leading-relaxed mt-1 ${isMidnight ? "text-slate-400" : "text-[#8E7D7A]"}`}>
                If you or someone else is experiencing severe distress, active self-harm impulses, or wishes to end life, please dial <strong className="text-rose-400">988</strong> immediately or text <strong className="text-rose-400">HOME</strong> to <strong className="text-rose-400">741741</strong> for free, confidential, 24/7 support.
              </p>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: HIGH FIDELITY SMARTPHONE HANDSET CONTAINER */}
        <div className="w-full max-w-[390px] xl:max-w-[420px] shrink-0 self-center md:my-0 my-10 relative">
          
          {/* Outer physical phone casing customized to balance light and dark modes */}
          <div className={`relative border-[11px] rounded-[50px] overflow-hidden h-[740px] flex flex-col transition-all duration-500 ${
            isMidnight 
              ? "border-slate-800 bg-slate-950 shadow-[0_24px_64px_-12px_rgba(0,0,0,0.85)]" 
              : "border-[#6D5A57]/90 bg-white shadow-[0_24px_64px_-12px_rgba(109,90,87,0.15)]"
          }`}>
            
            {/* Camera / Speaker Notch block */}
            <div className={`absolute top-2.5 left-1/2 transform -translate-x-1/2 w-32 h-6 rounded-full z-50 flex items-center justify-between px-3.5 ${
              isMidnight ? "bg-slate-950" : "bg-[#6D5A57]"
            }`}>
              <div className="w-2 h-2 rounded-full bg-slate-900/40 border border-slate-800" />
              <div className="w-10 h-1 bg-slate-900/40 rounded-full" />
              <div className="w-2.5 h-2.5 rounded-full bg-[#1A2E44]/10" />
            </div>

            {/* Simulated Handset status bar */}
            <div className={`px-6 pt-5 pb-2.5 border-b flex justify-between items-center text-[10px] font-mono z-40 select-none ${
              isMidnight 
                ? "bg-slate-950/45 border-white/5 text-slate-400" 
                : "bg-white/30 border-black/5 text-[#4A3F3D]"
            }`}>
              <span className="font-semibold">10:15 AM</span>
              <div className="flex items-center gap-1">
                <span>5G</span>
                <span className={`w-3.5 h-2 rounded-xs border p-0.2 flex ${isMidnight ? "border-slate-700" : "border-[#4A3F3D]"}`}>
                  <span className={`w-2.5 h-full block rounded-2xs ${isMidnight ? "bg-slate-400" : "bg-[#4A3F3D]"}`} />
                </span>
              </div>
            </div>

            {/* DYNAMIC SCREEN CHANGER FRAME AND SCROLL BODY */}
            <div className={`flex-1 overflow-hidden relative flex flex-col ${currentThemeClass}`}>
              
              {/* SCREEN 1: SPLASH VIEW */}
              {currentScreen === AppScreen.Splash && (
                <div className="flex-grow flex flex-col items-center justify-between p-6 py-12 text-center text-[#5A3E36]">
                  
                  {/* Floating particles aesthetic */}
                  <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
                    <div className="absolute top-[20%] left-[10%] w-24 h-24 rounded-full bg-rose-200/40 filter blur-xl animate-float-sky" />
                    <div className="absolute bottom-[30%] right-[5%] w-32 h-32 bg-orange-200/40 rounded-full filter blur-2xl animate-aura-pulse" />
                  </div>

                  <div className="z-10 mt-12 flex flex-col items-center">
                    <div className="w-16 h-16 rounded-full bg-linear-to-tr from-orange-400 to-rose-300 flex items-center justify-center shadow-lg shadow-rose-300/40 animate-warm-pulse mb-4">
                      <Heart className="w-8 h-8 text-white fill-white/10" />
                    </div>
                    <h2 className="text-3xl font-display font-medium tracking-tight text-[#4A312A]">InnerSpace</h2>
                    <p className="text-[11px] uppercase tracking-widest text-[#8A6F66]/80 font-bold mt-1 font-sans">
                      A quiet sanctuary
                    </p>
                  </div>

                  <div className="z-10 w-full flex flex-col gap-4">
                    <div className="bg-white/40 p-4 rounded-3xl border border-rose-100/30 text-[#8A6F66]">
                      <p className="text-xs leading-relaxed font-medium">
                        "Your thoughts are not storms to be feared. They are merely clouds, shifting slowly against physical skies."
                      </p>
                    </div>

                    <button
                      onClick={() => setCurrentScreen(AppScreen.Auth)}
                      className="py-3 bg-linear-to-r from-orange-300 via-rose-300 to-orange-200 hover:from-orange-400 hover:to-rose-300 text-stone-800 text-xs font-bold rounded-2xl shadow-md transition-transform active:scale-98"
                    >
                      Step softly inside
                    </button>
                  </div>
                </div>
              )}

              {/* SCREEN 2: AUTH / CREATIVE IDENTITY SIGNUP */}
              {currentScreen === AppScreen.Auth && (
                <div className="flex-grow flex flex-col p-5 justify-between text-[#5A3E36]">
                  
                  <div className="text-left mt-4 flex flex-col gap-4">
                    <div>
                      <h2 className="text-lg font-display font-bold text-[#4A312A] flex items-center gap-1">
                        <Sparkles className="w-5 h-5 text-rose-400" />
                        Creative Identity
                      </h2>
                      <p className="text-xs text-[#8A6F66] mt-0.5 leading-normal">
                        InnerSpace connects souls anonymized. Select a preset aesthetic tag or design your own style. No photo or password required.
                      </p>
                    </div>

                    {/* Username Selector Box */}
                    <div className="flex flex-col gap-1 text-left mt-2">
                      <label className="text-[10px] text-[#8A6F66] font-bold uppercase tracking-wider">Aesthetic username choice:</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          className="flex-grow p-2.5 bg-white/70 border border-rose-100 text-xs font-mono font-bold rounded-xl focus:outline-none focus:ring-1 focus:ring-rose-300 text-left"
                        />
                        <button
                          type="button"
                          onClick={handleRandomizeName}
                          className="p-2.5 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-xl text-xs"
                          title="Generate matching creative preset"
                        >
                          <RefreshCw className="w-4 h-4 animate-spin-slow" />
                        </button>
                      </div>
                    </div>

                    {/* Aesthetic Avatar picker */}
                    <div className="flex flex-col gap-2 text-left">
                      <span className="text-[10px] text-[#8A6F66] font-bold uppercase tracking-wider">Select Your Spirit Character:</span>
                      <div className="grid grid-cols-3 gap-2">
                        {AESTHETIC_AVATARS.map((av) => {
                          const isSelected = selectedAvatarId === av.id;
                          return (
                            <button
                              key={av.id}
                              type="button"
                              onClick={() => {
                                setSelectedAvatarId(av.id);
                                setCustomAuraColor(av.auraColor);
                              }}
                              className={`p-1 bg-white/60 hover:bg-white rounded-2xl border transition-all flex flex-col items-center ${
                                isSelected ? "ring-2 ring-rose-400 border-rose-100 shadow-sm" : "opacity-80 border-rose-100/30"
                              }`}
                            >
                              <div className="h-14 w-14 overflow-hidden rounded-full flex items-center justify-center p-0.5">
                                <svg viewBox="0 0 100 100" dangerouslySetInnerHTML={{ __html: av.svgHtml }} />
                              </div>
                              <span className="text-[8px] font-bold text-stone-600 tracking-tight text-center pb-1">
                                {av.name}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setCurrentScreen(AppScreen.MoodOnboarding)}
                    className="py-3 w-full bg-linear-to-r from-orange-300 to-rose-300 text-[#4A312A] text-xs font-bold rounded-2xl shadow-md transition"
                  >
                    Register Spirit Presence
                  </button>
                </div>
              )}

              {/* SCREEN 3: MOOD WHEEL ONBOARDING */}
              {currentScreen === AppScreen.MoodOnboarding && (
                <div className="flex-grow flex flex-col p-5 justify-between text-[#5A3E36]">
                  
                  <div className="text-left mt-3 flex flex-col gap-4">
                    <div>
                      <h2 className="text-lg font-display font-bold text-[#4A312A] flex items-center gap-1">
                        <Smile className="w-5 h-5 text-rose-400" />
                        Emotional Check-In
                      </h2>
                      <p className="text-xs text-[#8A6F66] mt-0.5 leading-normal">
                        Select which weights or frequencies are flowing in your heart orbits today. This custom check-in launches customized wellness suggestions.
                      </p>
                    </div>

                    {/* Wheel selection grid */}
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {[
                        { key: "lonely", label: "Quiet Loneliness", emoji: "🕯️" },
                        { key: "overthinking", label: "Overthinking orbits", emoji: "🌀" },
                        { key: "heartbreak", label: "Tender Heartbreak", emoji: "🩹" },
                        { key: "burnout", label: "Heavy Burnout", emoji: "🌿" },
                        { key: "anxiety", label: "Fluttery Anxiety", emoji: "☁️" },
                        { key: "silent", label: "Need Pure Silence", emoji: "🌌" }
                      ].map((md) => {
                        const isSelected = selectedMoods.includes(md.key);
                        return (
                          <button
                            key={md.key}
                            type="button"
                            onClick={() => {
                              if (isSelected) {
                                setSelectedMoods(prev => prev.filter(k => k !== md.key));
                              } else {
                                setSelectedMoods(prev => [...prev, md.key]);
                              }
                            }}
                            className={`p-3 bg-white/70 hover:bg-white rounded-2xl border text-[#5A3E36] font-semibold text-xs flex items-center gap-2 transition ${
                              isSelected ? "ring-2 ring-rose-400 border-rose-100 shadow-xs" : "border-rose-100/30 opacity-80"
                            }`}
                          >
                            <span className="text-lg select-none">{md.emoji}</span>
                            <span className="truncate">{md.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <button
                    onClick={handleMoodSubmit}
                    disabled={isLoadingAura}
                    className="py-3 w-full bg-linear-to-r from-orange-300 to-rose-300 text-stone-800 text-xs font-bold rounded-2xl shadow-md transition disabled:opacity-50"
                  >
                    {isLoadingAura ? "Synthesizing Emotional Aura Gradient..." : "Explore My Personal Aura"}
                  </button>
                </div>
              )}

              {/* SCREEN 4: HOME DASHOARD BENTO HUB */}
              {currentScreen === AppScreen.Home && (
                <div className="flex-grow flex flex-col p-4 overflow-y-auto pb-6 text-[#5A3E36]">
                  
                  {/* Dashboard Profile Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2 text-left">
                      {/* Avatar wrap */}
                      <button 
                        onClick={() => setCurrentScreen(AppScreen.UserProfileCustomization)}
                        className="w-10 h-10 rounded-full border border-rose-200 bg-white shadow-xs p-0.5 flex items-center justify-center relative hover:scale-105 transition"
                      >
                        <svg viewBox="0 0 100 100" dangerouslySetInnerHTML={{ __html: currentAvatarInfo.svgHtml }} />
                      </button>
                      
                      <div>
                        <span className="text-[9px] text-[#8A6F66]/80 font-bold uppercase tracking-wider block">Cozy dweller</span>
                        <h3 className="text-xs font-bold text-stone-800 leading-none">@{username}</h3>
                      </div>
                    </div>

                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setCurrentScreen(AppScreen.Settings)}
                        className="p-1.5 bg-white/60 border border-stone-200/40 rounded-full text-stone-600 hover:text-stone-900 transition"
                      >
                        <Settings className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* HIGH-FIDELITY ACTIVE EMOTIONAL AURA GLOWING CARD */}
                  <div 
                    className="rounded-3xl p-4 text-left text-white shadow-xs mb-4 relative overflow-hidden flex flex-col transition-all duration-500"
                    style={{ background: customAuraColor }}
                  >
                    {/* Pulsing light spheres */}
                    <div className="absolute inset-0 z-0 opacity-40 mix-blend-color-dodge filter blur-xl animate-aura-pulse bg-radial from-rose-300 to-transparent" />
                    
                    <div className="z-10 flex justify-between items-start mb-2.5">
                      <div>
                        <span className="text-[9px] uppercase tracking-wider font-bold bg-white/20 px-2.5 py-0.5 rounded-full inline-block">
                          Active Aura Glow
                        </span>
                        <h4 className="text-lg font-display font-medium leading-tight mt-1.5">
                          {selectedMoods.length > 0 ? `${selectedMoods.join(" + ")} Sanctuary` : "Tranquil Spirit"}
                        </h4>
                      </div>

                      <span className="text-2xl select-none">🕊️</span>
                    </div>

                    <p className="text-[10px] leading-relaxed text-white/90 font-sans font-medium line-clamp-3 z-10">
                      {auraDescription}
                    </p>

                    <div className="mt-4 border-t border-white/20 pt-3 flex items-center justify-between text-[9px] font-bold z-10">
                      <span>Daily Streak Tracker: {streak} full days</span>
                      <span className="bg-white/20 px-2 py-0.5 rounded-md">Resilient Heart</span>
                    </div>
                  </div>

                  {/* DUSTY SAGE COMPANION QUICK-ACCESS PANEL */}
                  <div className="bg-stone-900 text-stone-200 rounded-3xl p-3.5 mb-4 text-left shadow-xs flex justify-between items-center relative overflow-hidden">
                    <div>
                      <span className="text-[8px] bg-rose-900 text-rose-100 font-mono px-1.5 py-0.2 rounded-full uppercase tracking-wider font-bold">Safe Listener Companion</span>
                      <h4 className="text-xs font-bold text-white mt-1.5">Consult AI Cosmo</h4>
                      <p className="text-[10px] text-stone-400 mt-0.5">Empathic advice from our customized compiler.</p>
                    </div>
                    <button
                      onClick={() => setIsCompanionOpen(true)}
                      className="px-3.5 py-1.5 bg-rose-900 hover:bg-rose-850 text-rose-100 text-[10px] font-bold rounded-lg transition"
                    >
                      Chat Live
                    </button>
                  </div>

                  {/* BENTO GRID SECTOR FOR HOME ACTIVITIES */}
                  <div className="text-left mb-2">
                    <span className="text-[10px] text-[#8A6F66]/80 font-bold uppercase tracking-wider block mb-2">Explore Healing Pathways:</span>
                    
                    <div className="grid grid-cols-2 gap-3">
                      
                      {/* Grid Item 1: Hear Out */}
                      <button
                        onClick={() => setCurrentScreen(AppScreen.HearOut)}
                        className="bg-white/80 rounded-2xl p-3 border border-rose-100/50 hover:bg-white transition-all text-left flex flex-col justify-between h-28 hover:scale-[1.02]"
                      >
                        <div className="w-8 h-8 rounded-xl bg-orange-100/50 flex items-center justify-center text-lg select-none">
                          👂
                        </div>
                        <div>
                          <span className="text-[11px] font-bold text-stone-800 block">Hear Out</span>
                          <span className="text-[9px] text-[#8A6F66] block leading-none mt-0.5">Anonymous safe queue list</span>
                        </div>
                      </button>

                      {/* Grid Item 2: Scream Out */}
                      <button
                        onClick={() => setCurrentScreen(AppScreen.ScreamOut)}
                        className="bg-white/80 rounded-2xl p-3 border border-rose-100/50 hover:bg-white transition-all text-left flex flex-col justify-between h-28 hover:scale-[1.02]"
                      >
                        <div className="w-8 h-8 rounded-xl bg-[#E8B4B8]/30 flex items-center justify-center text-lg select-none">
                          🌩️
                        </div>
                        <div>
                          <span className="text-[11px] font-bold text-stone-800 block">Scream therapy</span>
                          <span className="text-[9px] text-[#8A6F66] block leading-none mt-0.5">Frustration cloud release</span>
                        </div>
                      </button>

                      {/* Grid Item 3: Healing mini games */}
                      <button
                        onClick={() => setCurrentScreen(AppScreen.MiniGames)}
                        className="bg-white/80 rounded-2xl p-3 border border-rose-100/50 hover:bg-white transition-all text-left flex flex-col justify-between h-28 hover:scale-[1.02]"
                      >
                        <div className="w-8 h-8 rounded-xl bg-emerald-100/50 flex items-center justify-center text-lg select-none">
                          🎮
                        </div>
                        <div>
                          <span className="text-[11px] font-bold text-stone-800 block">Healing Games</span>
                          <span className="text-[9px] text-[#8A6F66] block leading-none mt-0.5">Atmosphere tapping & breathers</span>
                        </div>
                      </button>

                      {/* Grid Item 4: Mood Journal keepsakes */}
                      <button
                        onClick={() => setCurrentScreen(AppScreen.MoodJournal)}
                        className="bg-white/80 rounded-2xl p-3 border border-rose-100/50 hover:bg-white transition-all text-left flex flex-col justify-between h-28 hover:scale-[1.02]"
                      >
                        <div className="w-8 h-8 rounded-xl bg-amber-100/50 flex items-center justify-center text-lg select-none">
                          📓
                        </div>
                        <div>
                          <span className="text-[11px] font-bold text-stone-800 block">Doodle Journal</span>
                          <span className="text-[9px] text-[#8A6F66] block leading-none mt-0.5">Sticker keepers catalog</span>
                        </div>
                      </button>

                    </div>
                  </div>

                  {/* COZY MOOD PET PLANTS PROGRESS CARD */}
                  <div className="bg-white/60 rounded-3xl p-3 mt-4 border border-rose-100/50 text-left flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl select-none">🌱</span>
                      <div>
                        <h4 className="text-[11px] font-bold text-stone-800">Your Tranquil Mood Pet</h4>
                        <span className="text-[9px] text-stone-500">Patience Streak level: {plantGrowth}%</span>
                        <div className="w-24 h-1 bg-stone-100 rounded-full mt-1 overflow-hidden border border-stone-200/50">
                          <div className="h-full bg-emerald-400" style={{ width: `${plantGrowth}%` }} />
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => setPlantGrowth(p => Math.min(p + 10, 100))}
                      className="px-2.5 py-1 bg-stone-50 border border-stone-200 rounded-lg text-[9px] text-stone-600 font-semibold"
                    >
                      Water plant
                    </button>
                  </div>

                  {/* DYNAMIC COMPILER TIPS */}
                  <div className="bg-[#FAF4F0] rounded-2xl p-3.5 mt-4 text-left border border-rose-100/30">
                    <span className="text-[9px] text-orange-500 font-bold uppercase tracking-wider block mb-1">
                      🕊️ Personal AI Wellness Tips:
                    </span>
                    <ul className="text-[9px] text-stone-600 font-sans font-medium flex flex-col gap-1 list-disc pl-3 mt-1 leading-normal">
                      {aiWellnessTips.map((tip, idx) => (
                        <li key={idx}>{tip}</li>
                      ))}
                    </ul>
                  </div>

                </div>
              )}

              {/* SCREEN 5: HEAR OUT LIST */}
              {currentScreen === AppScreen.HearOut && (
                <HearOut theme={currentThemeProps} avatarList={AESTHETIC_AVATARS} />
              )}

              {/* SCREEN 6: SCREAM OUT THUMBNAILS */}
              {currentScreen === AppScreen.ScreamOut && (
                <ScreamOut 
                  theme={currentThemeProps} 
                  screams={screams} 
                  onAddScream={handleAddScream} 
                  onScreamReaction={handleScreamReaction} 
                />
              )}

              {/* SCREEN 7: USER CUSTOM PROFILE */}
              {currentScreen === AppScreen.UserProfileCustomization && (
                <div className="flex-grow flex flex-col p-5 justify-between text-[#5A3E36]">
                  
                  <div className="text-left mt-3 flex flex-col gap-4">
                    <button
                      onClick={() => setCurrentScreen(AppScreen.Home)}
                      className="text-[10px] text-stone-500 flex items-center gap-1 font-semibold hover:text-stone-800"
                    >
                      ← Back to Dashboard
                    </button>

                    <div>
                      <h2 className="text-lg font-display font-bold text-[#4A312A] flex items-center gap-1">
                        <User className="w-5 h-5 text-rose-400" />
                        Modify Aura Style
                      </h2>
                      <p className="text-xs text-[#8A6F66] mt-0.5 leading-normal">
                        Paint your daily aura manually or pick custom glowing masks inside the catalog structure.
                      </p>
                    </div>

                    <div className="flex items-center gap-4 bg-white/70 p-4 rounded-3xl border border-rose-100 text-left">
                      <div className="w-14 h-14 rounded-full overflow-hidden border border-rose-200 bg-white shadow-sm flex items-center justify-center p-0.5">
                        <svg viewBox="0 0 100 100" dangerouslySetInnerHTML={{ __html: currentAvatarInfo.svgHtml }} />
                      </div>
                      
                      <div>
                        <span className="text-[10px] text-[#A6C48A] uppercase font-bold font-mono">My Active Username</span>
                        <h3 className="text-sm font-bold text-stone-800 mt-0.5">@{username}</h3>
                        <span className="text-[9px] text-[#8A6F66] font-medium leading-none block">Theme Presets: {currentThemeProps.name}</span>
                      </div>
                    </div>

                    <div className="flex flex-col gap-3 text-left">
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Select glowing background aura:</span>
                      
                      <div className="flex flex-col gap-2">
                        {[
                          { grad: "linear-gradient(135deg, #FFD1BA 0%, #E8B4B8 100%)", label: "Peach Blossom Dawn" },
                          { grad: "linear-gradient(135deg, #E2DDF0 0%, #C2E0D5 100%)", label: "Lavender Grass Meadows" },
                          { grad: "linear-gradient(135deg, #1C162E 0%, #03040C 100%)", label: "Cosmic Nebula Static" }
                        ].map((gr, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setCustomAuraColor(gr.grad)}
                            className="bg-white/80 hover:bg-white rounded-xl p-2.5 border border-rose-100 flex items-center gap-3 transition-transform hover:scale-[1.01]"
                          >
                            <span className="w-5 h-5 rounded-full" style={{ background: gr.grad }} />
                            <span className="text-xs font-semibold text-stone-700">{gr.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setCurrentScreen(AppScreen.Home)}
                    className="py-2.5 bg-gradient-to-r from-orange-300 to-rose-300 text-stone-800 text-xs font-bold rounded-xl shadow-xs transition"
                  >
                    Save Aura Parameters
                  </button>
                </div>
              )}

              {/* SCREEN 8: THERAPY SERVICE BOOKER */}
              {currentScreen === AppScreen.TherapyBooking && (
                <TherapyBooking theme={currentThemeProps} onBookConfirm={handleBookTherapist} />
              )}

              {/* SCREEN 9: EMOTIONS GROUP ROOMS */}
              {currentScreen === AppScreen.EmotionalRooms && (
                <EmotionalRooms theme={currentThemeProps} avatarList={AESTHETIC_AVATARS} />
              )}

              {/* SCREEN 10: DOODLE STICKER JOURNAL */}
              {currentScreen === AppScreen.MoodJournal && (
                <MoodJournal 
                  theme={currentThemeProps} 
                  journalEntries={journalEntries} 
                  onAddJournal={handleAddJournal} 
                />
              )}

              {/* SCREEN 11: HEALING CHIMES AND RESPIRATORS */}
              {currentScreen === AppScreen.MiniGames && (
                <BreathingGame 
                  theme={currentThemeProps} 
                  onStreakUpdate={() => setStreak(s => s + 1)} 
                />
              )}

              {/* SCREEN 12: SETTINGS AND SWATCH CHANGER */}
              {currentScreen === AppScreen.Settings && (
                <div className="flex-grow flex flex-col p-5 justify-between text-[#5A3E36]">
                  
                  <div className="text-left mt-3 flex flex-col gap-4">
                    <button
                      onClick={() => setCurrentScreen(AppScreen.Home)}
                      className="text-[10px] text-stone-500 font-semibold flex items-center gap-1 hover:text-stone-800"
                    >
                      ← Back to Dashboard
                    </button>

                    <div>
                      <h2 className="text-lg font-display font-bold text-[#4A312A] flex items-center gap-1">
                        <Settings className="w-5 h-5 text-rose-400" />
                        Aesthetic Themes
                      </h2>
                      <p className="text-xs text-[#8A6F66] mt-0.5 leading-normal">
                        Switch color coordinates globally to adjust emotional background filters completely on the fly in our simulated preview.
                      </p>
                    </div>

                    <div className="flex flex-col gap-2">
                      <span className="text-[10px] text-[#8A6F66] font-bold uppercase tracking-wider block mb-1">Select Canvas preset swatch:</span>
                      
                      <div className="grid grid-cols-2 gap-2">
                        {Object.values(THEMES).map((th) => {
                          const isActive = activeTheme === th.id;
                          return (
                            <button
                              key={th.id}
                              type="button"
                              onClick={() => setActiveTheme(th.id)}
                              className={`p-3 bg-white/60 hover:bg-white border rounded-2xl flex items-center gap-2.5 transition-transform hover:scale-102 ${
                                isActive ? "ring-2 ring-rose-400 border-rose-200 font-bold" : "border-rose-100/30"
                              }`}
                            >
                              <span className="w-4.5 h-4.5 rounded-full shrink-0 border" style={{ backgroundColor: th.id === "peach" ? "#FFDCD3" : th.id === "lavender" ? "#E2D9FF" : th.id === "sage" ? "#DEEAE2" : th.id === "midnight" ? "#0E1527" : th.id === "cream" ? "#EFE6CE" : "#FFE2C5" }} />
                              <span className="text-[10px] text-stone-700 truncate">{th.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="bg-[#FAF4F0] p-3 rounded-2xl border border-rose-100/30 text-left">
                      <span className="text-[8px] text-[#A6C48A] uppercase font-bold font-mono">Workspace specifications</span>
                      <p className="text-[10px] text-[#8A6F66] mt-1 font-sans">
                        Local coordinates and chat feeds are saved inside sandbox memory. Dynamic updates are fully responsive.
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setCurrentScreen(AppScreen.Home)}
                    className="py-2.5 bg-gradient-to-r from-orange-300 to-rose-300 text-stone-800 text-xs font-bold rounded-xl transition"
                  >
                    Confirm Theme Swatch
                  </button>
                </div>
              )}

              {/* COZY FLOATING CHAT DRAWER: PROFESSIONAL AI COMPANION Cosmo */}
              {isCompanionOpen && (
                <div className="absolute inset-x-0 bottom-0 top-14 bg-stone-950 text-stone-200 rounded-t-[36px] z-50 flex flex-col shadow-2xl border-t border-stone-800 transition-all">
                  
                  {/* Chat Drawer Header */}
                  <div className="p-4 border-b border-stone-900 bg-stone-950 flex justify-between items-center text-left">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-full bg-rose-900/40 text-rose-300 border border-rose-900 flex items-center justify-center text-xl">
                        🌌
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white flex items-center gap-1 leading-none">
                          Cosmo Helper
                          <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                        </h4>
                        <span className="text-[9px] text-stone-400">Secure server-side Gemini 3.5</span>
                      </div>
                    </div>

                    <button
                      onClick={() => setIsCompanionOpen(false)}
                      className="p-1.5 bg-stone-900 hover:bg-stone-800 rounded-full text-stone-400 hover:text-white transition"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Chat streams list flow */}
                  <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3.5 scroll-smooth bg-stone-900/40">
                    {companionChat.map((msg) => {
                      const isMe = msg.sender === "user";
                      return (
                        <div
                          key={msg.id}
                          className={`flex flex-col max-w-[80%] ${
                            isMe ? "self-end items-end" : "self-start items-start"
                          }`}
                        >
                          <span className="text-[9px] text-stone-500 mb-0.5 font-mono">
                            {isMe ? "You" : "Cosmo (Companion)"}
                          </span>
                          <div
                            className={`p-3 rounded-2xl text-xs font-medium leading-relaxed text-left ${
                              isMe
                                ? "bg-rose-900 text-rose-50 rounded-tr-xs"
                                : "bg-stone-800 text-stone-100 rounded-tl-xs"
                            }`}
                          >
                            {msg.text}
                          </div>
                        </div>
                      );
                    })}

                    {isCompanionLoading && (
                      <div className="self-start flex flex-col items-start max-w-[80%]">
                        <span className="text-[9px] text-stone-500 mb-0.5 font-mono">Cosmo</span>
                        <div className="p-3 bg-stone-800 text-stone-300 rounded-2xl text-xs font-medium text-left rounded-tl-xs animate-pulse">
                          🌀 Dreaming up comforting symbols...
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Preset cozy prompt helpers */}
                  <div className="px-4 py-2 border-t border-stone-900 flex gap-1.5 overflow-x-auto bg-stone-950 select-none">
                    {[
                      "I feel so lonely today",
                      "How do I quiet stress?",
                      "Let's breathe together",
                    ].map((ps) => (
                      <button
                        key={ps}
                        type="button"
                        onClick={() => setCompanionInput(ps)}
                        className="bg-stone-900 border border-stone-800 px-3 py-1 text-[9px] font-semibold text-stone-400 hover:text-white rounded-full shrink-0 transition"
                      >
                        {ps}
                      </button>
                    ))}
                  </div>

                  {/* Message Input submit block */}
                  <form onSubmit={handleSendCompanionMessage} className="p-3.5 bg-stone-950 border-t border-stone-900 flex gap-2">
                    <input
                      type="text"
                      value={companionInput}
                      onChange={(e) => setCompanionInput(e.target.value)}
                      placeholder="Share what is pacing in your thoughts..."
                      className="flex-grow p-2.5 bg-stone-900 text-stone-100 placeholder-stone-500 text-xs rounded-xl focus:outline-none border border-stone-850 text-left"
                    />
                    <button
                      type="submit"
                      disabled={!companionInput.trim() || isCompanionLoading}
                      className="p-2.5 bg-rose-900 text-rose-100 hover:bg-rose-850 rounded-xl transition disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              )}

            </div>

            {/* Smartphone White Home line bar indicators */}
            <div className="bg-stone-100 py-3.5 z-40 flex justify-center border-t border-black/5 bg-linear-to-b from-white/9w to-white">
              <div className="w-28 h-1 bg-stone-800 rounded-full" />
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
