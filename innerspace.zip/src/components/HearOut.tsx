import React, { useState, useEffect } from "react";
import { MessageCircle, Heart, User, Sparkles, Mic, Phone, X, Shield, Activity, Send } from "lucide-react";
import { ChatMessage } from "../types";

interface ListenerUser {
  id: string;
  name: string;
  status: string;
  tag: string;
  isOnline: boolean;
  avatarId: string;
}

interface HearOutProps {
  theme: any;
  avatarList: any[];
}

export default function HearOut({ theme, avatarList }: HearOutProps) {
  // Toggle availability status
  const [isAvailableToHear, setIsAvailableToHear] = useState(false);
  const [selectedTag, setSelectedTag] = useState("Just venting");
  const [availabilityStatus, setAvailabilityStatus] = useState("Listening Soul");

  // Simulated listening queue
  const [listeners, setListeners] = useState<ListenerUser[]>([
    { id: "lst-1", name: "lonelysunflower", status: "Available to Hear", tag: "Need comfort", isOnline: true, avatarId: "dreamy-flower" },
    { id: "lst-2", name: "sleepy_ghost", status: "Listening Soul", tag: "Just venting", isOnline: true, avatarId: "cloud-spirit" },
    { id: "lst-3", name: "pinkvoid", status: "Safe Listener", tag: "Need silence with someone", isOnline: true, avatarId: "glowing-mask" },
    { id: "lst-4", name: "echo.within", status: "Open Heart", tag: "Need advice", isOnline: true, avatarId: "abstract-spirit" }
  ]);

  // Private Anonymous chat states
  const [chatPartner, setChatPartner] = useState<ListenerUser | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [heartbeatRate, setHeartbeatRate] = useState(60); // BPM pulse speed!
  const [isVoiceSupp, setIsVoiceSupp] = useState(false);

  // Trigger automated cute mock listening partner responses after 2s
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !chatPartner) return;

    const userMsg: ChatMessage = {
      id: `usr-msg-${Date.now()}`,
      sender: "user",
      text: chatInput,
      timestamp: "Just now"
    };

    setChatMessages(prev => [...prev, userMsg]);
    setChatInput("");

    // Simulate comforting response
    setTimeout(() => {
      const partnerReplies = [
        "I hear you so deeply. Please take all the space and time you need.",
        "Your feeling makes total sense. I am sitting here quietly supporting you.",
        "That sounds incredibly heavy. Thank you for sharing it with me. I'm listening.",
        "Let's just pause here together for a minute. You are entirely safe in this space with me."
      ];
      const randomReply = partnerReplies[Math.floor(Math.random() * partnerReplies.length)];
      
      const partnerMsg: ChatMessage = {
        id: `prt-msg-${Date.now()}`,
        sender: "listener",
        text: randomReply,
        timestamp: "Just now"
      };
      setChatMessages(prev => [...prev, partnerMsg]);
    }, 2000);
  };

  const handleStartChat = (listener: ListenerUser) => {
    setChatPartner(listener);
    setChatMessages([
      {
        id: "sys-0",
        sender: "system",
        text: `🔒 Anonymous private connection established with @${listener.name}. Connected with ${listener.tag} vibes.`,
        timestamp: "Now"
      },
      {
        id: "sys-1",
        sender: "listener",
        text: `Hello friend, I am here. Tell me whatever is weighing on your mind today, or let's just stay present in silent warmth. I'm ready to listen.`,
        timestamp: "Now"
      }
    ]);
  };

  return (
    <div className="flex flex-col h-full bg-linear-to-b from-stone-50 to-orange-50/10">
      
      {!chatPartner ? (
        /* SCREEN 1: LISTENERS DIRECTORY */
        <div className="flex flex-col h-full overflow-y-auto">
          
          {/* Header */}
          <div className="p-4 border-b border-rose-100/30">
            <h2 className="text-xl font-display font-semibold flex items-center gap-1.5 text-stone-800">
              <Activity className="w-5 h-5 text-rose-400" />
              Hear Out
            </h2>
            <p className="text-stone-500 text-xs">Empathetic souls holding safe anonymous spaces</p>
          </div>

          <div className="p-4 flex flex-col gap-4">
            
            {/* TOGGLE TO OFFR HELP AS A LISTENER */}
            <div className="bg-white/90 rounded-2xl p-4 border border-rose-100 shadow-sm text-left">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="text-xs font-bold text-stone-800">Offer Your Warm Ears</h3>
                  <p className="text-[10px] text-stone-500">Let others anonymize and talk with you</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isAvailableToHear}
                    onChange={(e) => setIsAvailableToHear(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-stone-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-400"></div>
                </label>
              </div>

              {isAvailableToHear && (
                <div className="mt-3 pt-3 border-t border-rose-100/30 flex flex-col gap-3">
                  <div>
                    <span className="text-[10px] text-stone-400 font-semibold uppercase tracking-wider block mb-1">Your Listener Persona Status:</span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {["Available to Hear", "Safe Listener", "Open Heart", "Listening Soul"].map((st) => (
                        <button
                          key={st}
                          onClick={() => setAvailabilityStatus(st)}
                          className={`px-3 py-1 text-[10px] rounded-lg transition text-center font-semibold border ${
                            availabilityStatus === st ? "bg-rose-50 border-rose-300 text-rose-700" : "bg-stone-50 border-stone-200 text-stone-500"
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-stone-400 font-semibold uppercase tracking-wider block mb-1">Select Which Vibe You Hold Space For:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {["Need comfort", "Need advice", "Just venting", "Need silence with someone"].map((tg) => (
                        <button
                          key={tg}
                          onClick={() => setSelectedTag(tg)}
                          className={`px-2.5 py-0.5 rounded-full text-[9px] font-bold transition border ${
                            selectedTag === tg ? "bg-stone-800 text-white border-stone-800" : "bg-stone-100 border-stone-200 text-stone-500"
                          }`}
                        >
                          {tg}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 bg-[#F1ECE9]/50 p-2.5 rounded-xl border border-rose-100/30">
                    <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping shrink-0" />
                    <p className="text-[10px] text-stone-600">
                      You are now officially listed on the dashboard as a <strong className="text-stone-800">"{availabilityStatus}"</strong> with <strong className="text-stone-800">"{selectedTag}"</strong> alignment. Standby lovingly.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* SEPARATE: DISCOVER empathetic SOULS BLOCK */}
            <div className="text-left mt-2">
              <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block mb-2.5">Empathetic souls online now:</span>
              
              <div className="flex flex-col gap-3">
                {listeners.map((listener) => {
                  const matchedAvatar = avatarList.find(av => av.id === listener.avatarId) || avatarList[0];
                  return (
                    <div
                      key={listener.id}
                      className="bg-white/80 rounded-2xl p-3.5 border border-rose-100/40 flex items-center justify-between hover:bg-white transition-all shadow-xs"
                    >
                      <div className="flex items-center gap-3">
                        {/* Avatar illustration */}
                        <div className="w-11 h-11 rounded-full overflow-hidden border border-rose-200/50 bg-[#FDFBF7] flex items-center justify-center p-0.5 relative">
                          <svg viewBox="0 0 100 100" dangerouslySetInnerHTML={{ __html: matchedAvatar.svgHtml }} />
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 rounded-full border-2 border-white animate-pulse" />
                        </div>

                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-stone-800">@{listener.name}</span>
                            <span className="text-[9px] bg-rose-50 text-rose-500 px-1.5 py-0.2 rounded-full font-semibold">
                              {listener.status}
                            </span>
                          </div>
                          <p className="text-[10px] text-stone-400 font-sans font-medium mt-0.5 mt-1">
                            Holds space for: <strong className="text-stone-700">{listener.tag}</strong>
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => handleStartChat(listener)}
                        className="p-2.5 bg-gradient-to-r from-orange-200 to-rose-200 hover:from-orange-300 hover:to-rose-300 text-stone-800 rounded-full transition shadow-xs"
                        title="Chat anonymously"
                      >
                        <MessageCircle className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* SCREEN 2: PRIVATE ACTIVE CHAT STREAM */
        <div className="flex flex-col h-full bg-stone-900 text-stone-200">
          
          {/* Active Partner Chat Header */}
          <div className="p-3 border-b border-stone-800 bg-stone-950 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button 
                onClick={() => setChatPartner(null)} 
                className="text-stone-400 hover:text-white mr-1 text-sm font-bold p-1 bg-stone-900 rounded-full"
              >
                ←
              </button>
              
              <div className="w-9 h-9 rounded-full bg-stone-800 flex items-center justify-center p-0.5">
                <svg viewBox="0 0 100 100" dangerouslySetInnerHTML={{ 
                  __html: (avatarList.find(av => av.id === chatPartner.avatarId) || avatarList[0]).svgHtml 
                }} />
              </div>

              <div className="text-left">
                <span className="text-xs font-bold text-white block">@{chatPartner.name}</span>
                <span className="text-[9px] text-[#A6C48A] flex items-center gap-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#A6C48A] animate-ping" />
                  Synced heart connection
                </span>
              </div>
            </div>

            {/* HEARTBEAT SYNC VISUALIZER COMPONENT */}
            <div className="flex items-center gap-2 bg-stone-900 border border-stone-800 px-3 py-1 rounded-full">
              <Heart 
                className="w-4 h-4 text-rose-500 fill-rose-500" 
                style={{
                  animation: "warmPulse 1.2s infinite ease-in-out"
                }}
              />
              <div className="text-right">
                <span className="text-[8px] opacity-50 block uppercase font-mono">My Heartbeat</span>
                <span className="text-[10px] font-mono leading-none font-bold text-rose-400">72 BPM</span>
              </div>
            </div>
          </div>

          {/* ACTIVE messages LIST PANEL */}
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 bg-stone-900/60 scroll-smooth">
            {chatMessages.map((msg) => {
              if (msg.sender === "system") {
                return (
                  <div key={msg.id} className="text-center py-2">
                    <span className="text-[10px] text-stone-500 bg-stone-950 border border-stone-800 px-3 py-1 rounded-full">
                      {msg.text}
                    </span>
                  </div>
                );
              }

              const isMe = msg.sender === "user";
              return (
                <div 
                  key={msg.id} 
                  className={`flex flex-col max-w-[80%] ${
                    isMe ? "self-end items-end" : "self-start items-start"
                  }`}
                >
                  <span className="text-[9px] text-stone-500 mb-0.5 font-mono">
                    {isMe ? "You" : `@${chatPartner.name}`}
                  </span>
                  <div 
                    className={`p-3 rounded-2xl text-xs font-medium leading-relaxed shadow-xs text-left ${
                      isMe 
                        ? "bg-rose-900/80 text-rose-50 rounded-tr-xs" 
                        : "bg-stone-800 text-stone-100 rounded-tl-xs"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom message and Voice simulated controller input */}
          <form onSubmit={handleSendMessage} className="p-3 bg-stone-950 border-t border-stone-900 flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsVoiceSupp(!isVoiceSupp)}
              className={`p-2 rounded-xl transition shrink-0 ${
                isVoiceSupp ? "bg-rose-900 text-rose-200" : "bg-stone-900 text-stone-400 hover:text-white"
              }`}
              title="Speak voice memo (Simulated)"
            >
              <Mic className="text-xs w-4 h-4" />
            </button>

            {isVoiceSupp ? (
              <div className="flex-1 flex items-center justify-between px-3 py-1.5 bg-stone-900 rounded-xl text-xs text-rose-300">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" stroke-width="2" />
                  Recording voice note (emotion analysis)...
                </span>
                <button 
                  type="button" 
                  onClick={() => {
                    setIsVoiceSupp(false);
                    setChatInput("🎵 Voice diary note containing anxious markers updated.");
                  }} 
                  className="text-[10px] font-bold text-white bg-rose-600 px-2 py-0.5 rounded-full"
                >
                  Post
                </button>
              </div>
            ) : (
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Type absolute truth in anonymize space..."
                className="flex-1 p-2 bg-stone-900 text-stone-100 placeholder-stone-500 text-xs rounded-xl focus:outline-none focus:ring-1 focus:ring-rose-800 border border-stone-800 text-left"
              />
            )}

            <button
              type="submit"
              disabled={!chatInput.trim()}
              className="p-2 bg-rose-900 text-rose-100 hover:bg-rose-850 rounded-xl transition disabled:opacity-50 shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
