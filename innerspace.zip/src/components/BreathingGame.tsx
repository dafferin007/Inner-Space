import React, { useState, useEffect, useRef } from "react";
import { Play, Pause, RefreshCw, Sparkles, Cloud, Music, Volume2, HelpCircle } from "lucide-react";

interface BreathingGameProps {
  theme: any;
  onStreakUpdate: () => void;
}

export default function BreathingGame({ theme, onStreakUpdate }: BreathingGameProps) {
  const [activeGame, setActiveGame] = useState<"breathe" | "rain" | "clouds">("breathe");
  
  // 1. Breathing states
  const [isBreathingActive, setIsBreathingActive] = useState(false);
  const [breathPhase, setBreathPhase] = useState<"idle" | "inhale" | "hold" | "exhale">("idle");
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [completedBreaths, setCompletedBreaths] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // 2. Cloud arranging states
  const [clouds, setClouds] = useState<{ id: number; x: number; y: number; scale: number; opacity: number }[]>([
    { id: 1, x: 20, y: 30, scale: 1.2, opacity: 0.8 },
    { id: 2, x: 60, y: 25, scale: 0.9, opacity: 0.6 },
    { id: 3, x: 40, y: 55, scale: 1.4, opacity: 0.75 },
    { id: 4, x: 15, y: 70, scale: 0.8, opacity: 0.5 },
    { id: 5, x: 75, y: 65, scale: 1.1, opacity: 0.7 }
  ]);
  const containerRef = useRef<HTMLDivElement>(null);

  // 3. Rain notes frequency synthesizing (Web Audio API)
  const [lastTapped, setLastTapped] = useState<number | null>(null);
  const [rainVolume, setRainVolume] = useState(0.5);

  const playRainTone = (index: number) => {
    try {
      // Create native web audio synthesizer
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      // Beautiful harmonic frequencies corresponding to a soothing pentatonic major scale (C Major pentatonic: C, D, E, G, A)
      const pentatonic = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25, 783.99, 880.00, 1046.50, 1174.66];
      const freq = pentatonic[index % pentatonic.length] || 330;
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      
      // Add slight vibrato for dreaminess
      const vibrato = ctx.createOscillator();
      const vibratoGain = ctx.createGain();
      vibrato.frequency.value = 4.5; // slow ripple
      vibratoGain.gain.value = 3;  // gentle ripple
      vibrato.connect(vibratoGain);
      vibratoGain.connect(osc.frequency);
      vibrato.start();
      
      // Envelope setup (rapid pluck attack and slow serene delay decay)
      gain.gain.setValueAtTime(0.01, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.15 * rainVolume, ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.8);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + 1.9);
      
      setLastTapped(index);
      setTimeout(() => setLastTapped(null), 100);
    } catch (e) {
      console.warn("Audio Context not allowed or blocked by policy", e);
    }
  };

  // 4. Breathing timer controller (4-7-8 breath)
  useEffect(() => {
    if (!isBreathingActive) {
      setBreathPhase("idle");
      setSecondsLeft(0);
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    setBreathPhase("inhale");
    setSecondsLeft(4);

    timerRef.current = setInterval(() => {
      setSecondsLeft(prev => {
        if (prev <= 1) {
          // Transition phases
          setBreathPhase(current => {
            if (current === "inhale") {
              setSecondsLeft(7);
              return "hold";
            } else if (current === "hold") {
              setSecondsLeft(8);
              return "exhale";
            } else {
              setCompletedBreaths(c => {
                const nextVal = c + 1;
                if (nextVal % 3 === 0) {
                  onStreakUpdate(); // Update streak stats in parent state inside local storage!
                }
                return nextVal;
              });
              setSecondsLeft(4);
              return "inhale";
            }
          });
          return 0; // Temp placeholder
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isBreathingActive]);

  const handleCloudClick = (id: number, e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clickX = ((e.clientX - rect.left) / rect.width) * 100;
    const clickY = ((e.clientY - rect.top) / rect.height) * 100;

    // Reposition cloud gently
    setClouds(prev =>
      prev.map(cloud =>
        cloud.id === id
          ? { ...cloud, x: Math.min(Math.max(clickX - 10, 5), 85), y: Math.min(Math.max(clickY - 10, 5), 80) }
          : cloud
      )
    );
  };

  const currentThemeText = theme.textColor;

  return (
    <div className="flex flex-col h-full overflow-y-auto pb-4">
      <div className="p-4 border-b border-rose-100/30 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-display font-semibold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-rose-400" />
            Healing Games
          </h2>
          <p className="text-xs text-stone-500">Soaking calm into small screen spaces</p>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex px-4 py-2 gap-1 bg-stone-100/50 rounded-lg mx-4 mt-3">
        <button
          onClick={() => setActiveGame("breathe")}
          className={`flex-1 py-1.5 text-xs font-medium rounded-md transition ${
            activeGame === "breathe" ? "bg-white shadow-sm font-semibold" : "text-stone-500 opacity-80"
          }`}
        >
          💨 Breathing
        </button>
        <button
          onClick={() => setActiveGame("rain")}
          className={`flex-1 py-1.5 text-xs font-medium rounded-md transition ${
            activeGame === "rain" ? "bg-white shadow-sm font-semibold" : "text-stone-500 opacity-80"
          }`}
        >
          🎵 Rain Tapper
        </button>
        <button
          onClick={() => setActiveGame("clouds")}
          className={`flex-1 py-1.5 text-xs font-medium rounded-md transition ${
            activeGame === "clouds" ? "bg-white shadow-sm font-semibold" : "text-stone-500 opacity-80"
          }`}
        >
          ☁️ Cloud Sky
        </button>
      </div>

      <div className="flex-1 px-4 mt-3">
        {/* GAME 1: BREATHING HUB */}
        {activeGame === "breathe" && (
          <div className="flex flex-col items-center justify-center py-6 text-center">
            <span className="text-xs font-semibold tracking-wider uppercase text-rose-400 px-3 py-1 bg-rose-50 rounded-full mb-3">
              4-7-8 Breathing Circle
            </span>
            
            <p className="text-xs text-stone-500 max-w-xs mb-8">
              Breathe in 4s, Hold 7s, Exhale 8s. Helps immediately quiet the nervous system.
            </p>

            {/* Bubble visualization */}
            <div className="relative w-48 h-48 flex items-center justify-center mb-8">
              {/* Outer pulsing shadow ring */}
              <div 
                className={`absolute inset-0 rounded-full transition-all duration-[3000ms] ease-in-out opacity-20 filter blur-lg ${
                  breathPhase === "inhale" ? "scale-125 bg-rose-300" : 
                  breathPhase === "hold" ? "scale-130 bg-amber-200" :
                  breathPhase === "exhale" ? "scale-90 bg-sky-200" : "scale-100 bg-rose-100"
                }`}
              />
              
              {/* Core Breathing Bubble */}
              <div
                className={`rounded-full flex flex-col items-center justify-center transition-all duration-[4000ms] text-stone-800 ${
                  breathPhase === "inhale" ? "w-44 h-44 bg-rose-200/90 shadow-lg" : 
                  breathPhase === "hold" ? "w-48 h-48 bg-amber-100/90 shadow-xl border border-amber-300/30" : 
                  breathPhase === "exhale" ? "w-32 h-32 bg-sky-100/90 shadow-sm" : 
                  "w-36 h-36 bg-rose-100/80 shadow border border-rose-100"
                }`}
              >
                <span className="text-xl font-display font-bold tracking-wide capitalize">
                  {breathPhase === "idle" ? "Relax" : breathPhase}
                </span>
                
                {secondsLeft > 0 && (
                  <span className="text-3xl font-mono font-bold mt-1 text-stone-800/80">
                    {secondsLeft}s
                  </span>
                )}
              </div>
            </div>

            {/* State & Controller */}
            <div className="mb-4">
              {breathPhase === "inhale" && <p className="text-xs font-medium text-rose-500">Inhale gently through your nose...</p>}
              {breathPhase === "hold" && <p className="text-xs font-medium text-amber-600">Rest the breath suspended in sweet calm...</p>}
              {breathPhase === "exhale" && <p className="text-xs font-medium text-sky-600">Sigh it completely out of your thoughts...</p>}
              {breathPhase === "idle" && <p className="text-xs text-stone-400">Ready to slow your pacing down?</p>}
            </div>

            <div className="flex gap-4 mb-4">
              <button
                onClick={() => setIsBreathingActive(!isBreathingActive)}
                className={`px-5 py-2 rounded-full text-xs font-semibold flex items-center gap-2 ${
                  isBreathingActive
                    ? "bg-stone-800 text-white"
                    : "bg-gradient-to-r from-orange-300 to-rose-300 text-stone-800 shadow-md"
                }`}
              >
                {isBreathingActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isBreathingActive ? "Stop Breathing" : "Start Breath Guide"}
              </button>
              
              <button
                onClick={() => {
                  setIsBreathingActive(false);
                  setCompletedBreaths(0);
                  setBreathPhase("idle");
                  setSecondsLeft(0);
                }}
                className="p-2 bg-white hover:bg-stone-50 border border-stone-200 rounded-full text-stone-600"
                title="Reset count"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-white/60 rounded-xl p-3 border border-stone-100 w-full max-w-sm flex items-center justify-between text-left">
              <div>
                <span className="text-xs text-stone-400">Cycles Completed</span>
                <p className="text-sm font-semibold text-stone-700">Self-regulating loops</p>
              </div>
              <div className="bg-rose-100 rounded-lg px-3 py-1 font-mono text-lg font-bold text-rose-600">
                {completedBreaths}
              </div>
            </div>
          </div>
        )}

        {/* GAME 2: RAIN TAPPER SYNTHESIZER */}
        {activeGame === "rain" && (
          <div className="flex flex-col py-3">
            <div className="text-center mb-4">
              <span className="text-xs font-semibold tracking-wider text-[#8A6F66] px-3 py-1 bg-stone-100 rounded-full mb-1 inline-block">
                Atmospheric Rain Chimes
              </span>
              <p className="text-xs text-stone-500 max-w-xs mx-auto">
                Tap on different droplets below to play custom bell notes synthesized instantly in your browser. Compose your peaceful rain landscape.
              </p>
            </div>

            {/* Volume control */}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-stone-100/50 rounded-lg mb-4 max-w-xs mx-auto">
              <Volume2 className="w-4 h-4 text-stone-400" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={rainVolume}
                onChange={(e) => setRainVolume(parseFloat(e.target.value))}
                className="w-24 h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-rose-400"
              />
              <span className="text-[10px] font-mono text-stone-500">{Math.round(rainVolume * 100)}%</span>
            </div>

            {/* Tap Grid */}
            <div className="grid grid-cols-4 gap-3 bg-white/40 p-4 rounded-2xl border border-stone-100 mb-4 h-56 items-center">
              {Array.from({ length: 12 }).map((_, index) => {
                const nodeColors = [
                  "from-teal-100/50 to-emerald-100/80",
                  "from-amber-100/50 to-orange-100/80",
                  "from-rose-100/50 to-pink-100/80",
                  "from-indigo-100/50 to-violet-100/80",
                ];
                const bgGradient = nodeColors[index % nodeColors.length];
                const isSelected = lastTapped === index;

                return (
                  <button
                    key={index}
                    onClick={() => playRainTone(index)}
                    className={`h-14 rounded-full bg-linear-to-b ${bgGradient} border border-white flex flex-col items-center justify-center gap-1 transition-all duration-150 transform hover:scale-105 active:scale-95 ${
                      isSelected ? "ring-2 ring-rose-400 shadow-md scale-102" : "shadow-xs"
                    }`}
                  >
                    <div className="w-1.5 h-3 rounded-full bg-white/80 animate-bounce" style={{ animationDelay: `${index * 120}ms` }} />
                    <span className="text-[9px] text-[#8A6F66] font-mono select-none">
                      Note {String.fromCharCode(65 + (index % 7))}{index + 1}
                    </span>
                  </button>
                );
              })}
            </div>

            <p className="text-[10px] text-center text-stone-400 italic">
              ✨ Best experienced with headphones in a quiet sanctuary room.
            </p>
          </div>
        )}

        {/* GAME 3: CLOUDS ARRANGING */}
        {activeGame === "clouds" && (
          <div className="flex flex-col py-2">
            <span className="text-center text-xs font-semibold text-rose-500 mb-1">Soothing Cloud Garden</span>
            <p className="text-center text-[11px] text-stone-500 mb-3">
              Click anywhere on the twilight sky box to move the puffy clouds. Give your overthinking mind a restful visual focus.
            </p>

            {/* Cloud Workspace Box */}
            <div
              ref={containerRef}
              className="relative w-full h-64 bg-gradient-to-b from-[#1E112A] via-[#35253F] to-[#59425E] rounded-2xl overflow-hidden border border-purple-950/20 shadow-inner"
            >
              {/* Star background decoration */}
              <div className="absolute inset-0 z-0">
                {Array.from({ length: 15 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute bg-white/70 rounded-full animate-pulse"
                    style={{
                      left: `${(i * 17) % 95}%`,
                      top: `${(i * 31) % 90}%`,
                      width: `${(i % 3) + 1.5}px`,
                      height: `${(i % 3) + 1.5}px`,
                      animationDuration: `${(i % 4) + 2}s`
                    }}
                  />
                ))}
              </div>

              {/* Glowing Ambient Moon */}
              <div className="absolute top-4 right-8 w-12 h-12 rounded-full bg-amber-100 shadow-[0_0_20px_rgba(255,248,220,0.4)] opacity-85 z-0" />

              {/* Draggable clouds */}
              {clouds.map((cloud) => (
                <div
                  key={cloud.id}
                  onClick={(e) => handleCloudClick(cloud.id, e)}
                  style={{
                    left: `${cloud.x}%`,
                    top: `${cloud.y}%`,
                    transform: `scale(${cloud.scale})`,
                    opacity: cloud.opacity,
                    cursor: "pointer",
                    transition: "all 0.6s cubic-bezier(0.16, 1, 0.3, 1)"
                  }}
                  className="absolute z-10 flex flex-col items-center hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.4)] select-none"
                >
                  <Cloud className="w-12 h-10 text-white fill-white/90 filter blur-[0.4px]" />
                  <span className="text-[8px] bg-black/30 text-white px-1.5 py-0.2 rounded-full mt-1">Arranged</span>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center mt-3 px-1">
              <span className="text-[10px] text-purple-200">Sky status: Tranquil dusk</span>
              <button
                onClick={() => {
                  setClouds([
                    { id: 1, x: 10, y: 35, scale: 1.2, opacity: 0.8 },
                    { id: 2, x: 70, y: 15, scale: 0.9, opacity: 0.6 },
                    { id: 3, x: 45, y: 60, scale: 1.4, opacity: 0.75 },
                    { id: 4, x: 22, y: 75, scale: 0.8, opacity: 0.5 },
                    { id: 5, x: 80, y: 55, scale: 1.1, opacity: 0.7 }
                  ]);
                }}
                className="text-[10px] text-stone-500 flex items-center gap-1 hover:text-stone-800"
              >
                <RefreshCw className="w-3 h-3" /> Scatter Clouds
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
