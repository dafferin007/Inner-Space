import React, { useState, useEffect } from "react";
import { Users, Volume2, VolumeX, MessageCircle, Send, Shield, Sparkles, Heart } from "lucide-react";
import { SUPPORT_ROOMS, ChatMessage, SupportRoom } from "../types";

interface EmotionalRoomsProps {
  theme: any;
  avatarList: any[];
}

export default function EmotionalRooms({ theme, avatarList }: EmotionalRoomsProps) {
  const [selectedRoom, setSelectedRoom] = useState<SupportRoom | null>(null);
  const [isPlayingAmbient, setIsPlayingAmbient] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [roomChats, setRoomChats] = useState<Record<string, ChatMessage[]>>({
    "room-lonely": [
      { id: "rm-1", sender: "listener", text: "Welcome cozy souls. We are sitting quietly in the twilight. Feel free to just listen or post a word.", timestamp: "10m ago" },
      { id: "rm-2", sender: "user", text: "It is comforting seeing other people's candles burning. Makes me feel a little less distant.", timestamp: "4m ago" }
    ],
    "room-overthinking": [
      { id: "rm-3", sender: "listener", text: "Take a deep breath and let the scrolling list replace your racing loops.", timestamp: "6m ago" }
    ],
    "room-heartbreak": [
      { id: "rm-4", sender: "listener", text: "There is immense tenderness in this room. Take your time. We are here together.", timestamp: "3m ago" }
    ],
    "room-burnout": [
      { id: "rm-5", sender: "listener", text: "Lay your shields down. No achievements needed here of any kind.", timestamp: "12m ago" }
    ]
  });

  // Automated mock group chat contributions to make the room feel real and alive!
  useEffect(() => {
    if (!selectedRoom) return;

    const timer = setInterval(() => {
      const roomId = selectedRoom.id;
      const contributions: Record<string, string[]> = {
        "room-lonely": [
          "Just made a hot cup of lavender tea. Sending a virtual cup to everyone here. ☕",
          "Sometimes I just stare at the glowing candle indicator. It's so peaceful.",
          "I'm here for anyone who needs to vent."
        ],
        "room-overthinking": [
          "What if we just let the cloud arranging be our only priority for 2 minutes?",
          "My mind is quieter already.",
          "It's okay to make mistakes."
        ],
        "room-heartbreak": [
          "One tiny step at a time. We can mend.",
          "It hurts so much. Putting my heavy pieces in the soil here with you.",
          "You are so strong for carrying this."
        ],
        "room-burnout": [
          "Just sighed deeply. Feels so good to not have to work.",
          "Rest is completely productive.",
          "Soft grass vibes."
        ]
      };

      const roomReplies = contributions[roomId] || ["Sending quiet support."];
      const randomReply = roomReplies[Math.floor(Math.random() * roomReplies.length)];

      const randomNames = ["echo_soul", "twilight_dew", "sleepy_ghost", "starlight_mind"];
      const randomSender = randomNames[Math.floor(Math.random() * randomNames.length)];

      const botMsg: ChatMessage = {
        id: `bot-rm-${Date.now()}`,
        sender: "listener",
        text: `[${randomSender}] ${randomReply}`,
        timestamp: "Just now"
      };

      setRoomChats(prev => ({
        ...prev,
        [roomId]: [...(prev[roomId] || []), botMsg]
      }));
    }, 10000); // Trigger every 10 seconds

    return () => clearInterval(timer);
  }, [selectedRoom]);

  const handlePostRoomChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !selectedRoom) return;

    const userMsg: ChatMessage = {
      id: `usr-rm-${Date.now()}`,
      sender: "user",
      text: chatInput,
      timestamp: "Just now"
    };

    const roomId = selectedRoom.id;
    setRoomChats(prev => ({
      ...prev,
      [roomId]: [...(prev[roomId] || []), userMsg]
    }));
    setChatInput("");
  };

  const activeMessages = selectedRoom ? roomChats[selectedRoom.id] || [] : [];

  return (
    <div className="flex flex-col h-full bg-linear-to-b from-stone-50 to-[#FCFAF5]">
      
      {!selectedRoom ? (
        /* SCREEN 1: ROOMS INDEX SELECTION */
        <div className="flex flex-col h-full overflow-y-auto">
          <div className="p-4 border-b border-rose-100/30 text-left">
            <h2 className="text-xl font-display font-semibold flex items-center gap-1.5 text-stone-800">
              <Users className="w-5 h-5 text-rose-400" />
              Emotional Rooms
            </h2>
            <p className="text-[#8A6F66] text-xs">Calming shelters with shared atmospheric sounds</p>
          </div>

          <div className="p-4 flex flex-col gap-4">
            
            <div className="bg-white rounded-2xl p-3 border border-rose-100/30 text-center">
              <p className="text-[11px] text-[#8A6F66] leading-relaxed">
                🌸 Enter an emotion room alongside others experiencing similar currents. Each contains custom ambient soundtracks to synchronize peaceful wavelengths.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3 text-left">
              {SUPPORT_ROOMS.map((room) => (
                <button
                  key={room.id}
                  onClick={() => setSelectedRoom(room)}
                  className={`bg-linear-to-r ${room.color} hover:shadow-xs p-4.5 rounded-2xl border border-rose-100/50 flex items-start gap-3.5 transition-transform duration-200 hover:scale-[1.01]`}
                >
                  <span className="text-3xl p-2 bg-white/70 backdrop-blur-xs rounded-xl shadow-xs shrink-0 select-none">
                    {room.emoji}
                  </span>

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-stone-800">{room.name}</h3>
                      <span className="text-[9px] bg-stone-900/10 text-stone-700 px-2 py-0.5 rounded-full font-bold">
                        👥 {room.userCount} online
                      </span>
                    </div>
                    <p className="text-[10px] text-stone-500 font-sans mt-0.5 leading-normal">
                      {room.description}
                    </p>
                    <span className="text-[9px] text-[#8A6F66] font-mono mt-2 block font-semibold">
                      🎵 Soundscape: {room.ambientSound}
                    </span>
                  </div>
                </button>
              ))}
            </div>

          </div>
        </div>
      ) : (
        /* SCREEN 2: ACTIVE ROOM WITH MESSAGES FLOW */
        <div className="flex flex-col h-full bg-linear-to-b from-stone-950 to-stone-900 text-stone-300">
          
          {/* Room Header Controls */}
          <div className="p-3 border-b border-stone-850 bg-stone-950 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => setSelectedRoom(null)}
                className="text-stone-400 hover:text-white mr-1 text-sm font-bold p-1 bg-stone-900 rounded-full"
              >
                ←
              </button>

              <span className="text-2xl select-none">{selectedRoom.emoji}</span>
              
              <div className="text-left">
                <span className="text-xs font-bold text-white block">{selectedRoom.name}</span>
                <span className="text-[9px] text-stone-500">
                  Sentiment: <strong className="text-rose-400">{selectedRoom.sentiment}</strong>
                </span>
              </div>
            </div>

            {/* Ambient Soundscape Controller toggle */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPlayingAmbient(!isPlayingAmbient)}
                className={`flex items-center gap-1 px-3 py-1 text-[10px] font-bold rounded-full transition ${
                  isPlayingAmbient ? "bg-rose-900 text-rose-100" : "bg-stone-900 text-stone-400 border border-stone-800"
                }`}
                title="Toggle soundtrack (Synthesized binaural beat)"
              >
                {isPlayingAmbient ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                <span>{isPlayingAmbient ? "Ambience on" : "Mute Sound"}</span>
              </button>
            </div>
          </div>

          {/* Sound wave graphic overlay when active to show aesthetic immersion */}
          {isPlayingAmbient && (
            <div className="bg-rose-950/20 px-4 py-2 border-b border-rose-950/30 flex items-center justify-between text-left">
              <span className="text-[10px] text-rose-400 font-mono animate-pulse">
                🔊 Playing: <strong>{selectedRoom.ambientSound}</strong> (Theta meditation frequencies)
              </span>
              <div className="flex gap-0.5 items-end h-3">
                {[1, 2, 3, 4, 5, 2, 4, 1].map((h, i) => (
                  <div 
                    key={i} 
                    className="w-0.5 bg-rose-400 animate-pulse" 
                    style={{ 
                      height: `${h * 20}%`, 
                      animationDelay: `${i * 150}ms`,
                      animationDuration: "1s"
                    }} 
                  />
                ))}
              </div>
            </div>
          )}

          {/* lounge Chat feed scrolling panel */}
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
            <div className="text-center py-1">
              <span className="text-[10px] text-stone-500 border border-stone-850 bg-stone-950 px-3 py-0.5 rounded-full">
                🔒 Anonymous group logs. Respect and hold presence.
              </span>
            </div>

            {activeMessages.map((msg) => {
              const isMe = msg.sender === "user";
              
              return (
                <div 
                  key={msg.id}
                  className={`flex flex-col max-w-[85%] ${isMe ? "self-end items-end" : "self-start items-start"}`}
                >
                  <span className="text-[9px] text-stone-500 mb-0.5 font-mono">
                    {isMe ? "You" : "Anonymous Soul"}
                  </span>
                  <div 
                    className={`p-3 rounded-2xl text-xs font-medium leading-relaxed shadow-xs text-left ${
                      isMe ? "bg-rose-950 border border-rose-900 text-rose-100 rounded-tr-xs" : "bg-stone-850 text-stone-200 rounded-tl-xs"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Chat Post Input Form */}
          <form onSubmit={handlePostRoomChat} className="p-3 bg-stone-950 border-t border-stone-900 flex items-center gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Type peaceful whisper in group room..."
              className="flex-1 p-2 bg-stone-900 text-stone-100 placeholder-stone-500 text-xs rounded-xl focus:outline-none focus:ring-1 focus:ring-rose-800 border border-stone-800 text-left"
            />
            <button
              type="submit"
              disabled={!chatInput.trim()}
              className="p-2 bg-rose-950 text-rose-300 hover:bg-rose-900 rounded-xl transition disabled:opacity-50 shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}
    </div>
  );
}
