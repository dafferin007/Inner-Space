import React, { useRef, useState, useEffect } from "react";
import { BookOpen, PenTool, Sparkles, AlertCircle, Plus, Calendar, Trash2, Check, Smile } from "lucide-react";
import { JournalEntry } from "../types";

interface MoodJournalProps {
  theme: any;
  journalEntries: JournalEntry[];
  onAddJournal: (note: string, sticker: string, moodLevel: number, doodleUrl?: string) => void;
}

export const JOURNAL_STICKERS = ["🌸", "☁️", "🌟", "🌧️", "🕯️", "🩹", "🌿", "🦋", "☕"];

export default function MoodJournal({ theme, journalEntries, onAddJournal }: MoodJournalProps) {
  const [note, setNote] = useState("");
  const [sticker, setSticker] = useState("🌸");
  const [moodLevel, setMoodLevel] = useState(3);
  const [activeTab, setActiveTab] = useState<"compose" | "history">("compose");

  // Canvas states
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [strokeColor, setStrokeColor] = useState("#E8B4B8"); // Default warm rose
  const [brushWidth, setBrushWidth] = useState(4);

  const initCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // Fill background with soft cream representing physical fiber paper
    ctx.fillStyle = "#FAF8F5";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  useEffect(() => {
    if (activeTab === "compose") {
      setTimeout(initCanvas, 50); // Delay slightly for DOM tracking
    }
  }, [activeTab]);

  const handleStartDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    setIsDrawing(true);
    ctx.beginPath();
    
    // Handle touch vs mouse
    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;
    
    if ("touches" in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = clientX - rect.left;
    const y = clientY - rect.top;
    
    ctx.moveTo(x, y);
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = brushWidth;
    ctx.lineCap = "round";
  };

  const handleDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;
    
    if ("touches" in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const handleStopDraw = () => {
    setIsDrawing(false);
  };

  const handleClearCanvas = () => {
    initCanvas();
  };

  const handleSaveJournal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!note.trim()) return;

    let doodleUrl = undefined;
    const canvas = canvasRef.current;
    if (canvas) {
      // Export vector data URL
      doodleUrl = canvas.toDataURL("image/png");
    }

    onAddJournal(note, sticker, moodLevel, doodleUrl);
    setNote("");
    setSticker("🌸");
    setMoodLevel(3);
    setActiveTab("history");
  };

  return (
    <div className="flex flex-col h-full bg-[#FCFAF7]">
      {/* Header */}
      <div className="p-4 border-b border-rose-100/30 flex items-center justify-between bg-white/50">
        <div>
          <h2 className="text-xl font-display font-semibold flex items-center gap-1.5 text-stone-800">
            <BookOpen className="w-5 h-5 text-rose-400" />
            Emotion Journal
          </h2>
          <p className="text-stone-500 text-xs">A warm cedar trunk for your precious secrets</p>
        </div>

        <div className="flex bg-stone-100/60 rounded-full p-0.5">
          <button
            onClick={() => setActiveTab("compose")}
            className={`px-3 py-1 text-[11px] font-semibold rounded-full transition ${
              activeTab === "compose" ? "bg-white text-stone-800 shadow-xs" : "text-stone-500"
            }`}
          >
            Compose
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`px-3 py-1 text-[11px] font-semibold rounded-full transition ${
              activeTab === "history" ? "bg-white text-stone-800 shadow-xs" : "text-stone-500"
            }`}
          >
            Past Keepsakes
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col">
        {activeTab === "compose" ? (
          <form onSubmit={handleSaveJournal} className="flex flex-col gap-4 text-left">
            {/* Note component */}
            <div className="flex flex-col gap-1.5">
              <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">How is your spirit pacing today?</span>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Today I feel a bit like morning fog—somewhat quiet, fragile but waiting for sunlight..."
                className="w-full text-xs font-medium p-3 bg-white border border-rose-100 rounded-xl leading-relaxed focus:ring-1 focus:ring-rose-200 focus:outline-none"
                rows={4}
              />
            </div>

            {/* Sticker selector row */}
            <div className="flex flex-col gap-1.5">
              <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">Choose a Visual Sticker representing this state:</span>
              <div className="flex gap-2 bg-white p-2 rounded-xl border border-rose-100 overflow-x-auto justify-between select-none">
                {JOURNAL_STICKERS.map((stk) => (
                  <button
                    key={stk}
                    type="button"
                    onClick={() => setSticker(stk)}
                    className={`text-xl p-1.5 rounded-lg transition ${
                      sticker === stk ? "bg-rose-100 scale-110" : "hover:bg-stone-50"
                    }`}
                  >
                    {stk}
                  </button>
                ))}
              </div>
            </div>

            {/* Expressive Canvas Draw Component */}
            <div className="flex flex-col gap-1.5 bg-white p-3.5 rounded-2xl border border-rose-100">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-xs font-bold text-stone-700 flex items-center gap-1">
                  <PenTool className="w-3.5 h-3.5 text-rose-400" />
                  Doodle your feelings (Abstract release)
                </span>
                
                <button
                  type="button"
                  onClick={handleClearCanvas}
                  className="text-[9px] font-bold text-stone-400 border border-stone-200 px-2 py-0.5 rounded-md hover:text-stone-800"
                >
                  Clear Screen
                </button>
              </div>

              {/* Color swatches for doodle brush */}
              <div className="flex gap-2 items-center mb-2">
                <span className="text-[9px] text-[#A6C48A] uppercase font-bold mr-1 font-mono">Brush color:</span>
                {[
                  { hex: "#E8B4B8", label: "Pink" },
                  { hex: "#A6C1EE", label: "Blue" },
                  { hex: "#CEE2D5", label: "Sage" },
                  { hex: "#EEDBB0", label: "Honey" },
                  { hex: "#1C162E", label: "Ink" },
                ].map((colorItem) => (
                  <button
                    key={colorItem.hex}
                    type="button"
                    onClick={() => setStrokeColor(colorItem.hex)}
                    className={`w-3.5 h-3.5 rounded-full border border-white transition-transform ${
                      strokeColor === colorItem.hex ? "ring-2 ring-stone-700 scale-115" : ""
                    }`}
                    style={{ backgroundColor: colorItem.hex }}
                    title={colorItem.label}
                  />
                ))}
              </div>

              {/* Interactive Canvas Grid */}
              <canvas
                ref={canvasRef}
                width={280}
                height={160}
                onMouseDown={handleStartDraw}
                onMouseMove={handleDrawing}
                onMouseUp={handleStopDraw}
                onMouseLeave={handleStopDraw}
                onTouchStart={handleStartDraw}
                onTouchMove={handleDrawing}
                onTouchEnd={handleStopDraw}
                className="w-full h-40 border border-rose-100 rounded-xl cursor-crosshair touch-none"
              />
            </div>

            {/* Submit save button */}
            <button
              type="submit"
              disabled={!note.trim()}
              className="py-2 bg-gradient-to-r from-orange-400 to-rose-300 hover:from-orange-500 hover:to-rose-400 text-white rounded-xl text-xs font-bold shadow-md transition disabled:opacity-60 flex items-center justify-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Log Into Keepsakes Inventory</span>
            </button>
          </form>
        ) : (
          /* HISTORIC Saved JOURNALS LIST */
          <div className="flex flex-col gap-4">
            {journalEntries.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center py-20 text-center opacity-85">
                <p className="text-xs text-stone-500 font-medium">Your keepers inventory is completely clean.</p>
                <button
                  onClick={() => setActiveTab("compose")}
                  className="mt-2 text-xs text-rose-400 font-semibold underline"
                >
                  Write down your first secret
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-3.5">
                {journalEntries.map((entry) => (
                  <div
                    key={entry.id}
                    className="bg-white rounded-2xl p-4 border border-rose-100/30 shadow-xs text-left"
                  >
                    <div className="flex items-center justify-between border-b border-stone-50 pb-2 mb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl select-none">{entry.sticker}</span>
                        <div>
                          <span className="text-[10px] uppercase font-bold text-stone-400">Recorded entry</span>
                          <span className="text-[9px] font-mono block text-neutral-400 leading-none">{entry.date}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <span className="text-[8px] bg-amber-50 text-amber-500 font-mono px-2 py-0.5 rounded-full font-bold">
                          Mood: {entry.moodLevel}/5
                        </span>
                      </div>
                    </div>

                    <p className="text-xs font-sans font-medium leading-relaxed text-stone-700 whitespace-pre-wrap mb-3.5">
                      {entry.note}
                    </p>

                    {/* Render saved canvas drawings if captured! */}
                    {entry.doodleDataUrl && (
                      <div className="mt-2 border border-rose-100/40 rounded-xl overflow-hidden bg-[#FAF8F5]">
                        <span className="text-[8px] text-stone-400 uppercase font-bold block p-2 border-b border-rose-100/10">Attached emotional doodle:</span>
                        <img 
                          src={entry.doodleDataUrl} 
                          alt="Emotional doodle" 
                          className="w-full h-auto object-cover border-none"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
