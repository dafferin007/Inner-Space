import React, { useState } from "react";
import { Calendar, Check, Star, Shield, HelpCircle, PhoneCall, Video, Heart, AlertCircle } from "lucide-react";
import { COUNSELORS, Counselor } from "../types";

interface TherapyBookingProps {
  theme: any;
  onBookConfirm: (counselorName: string, date: string, time: string) => void;
}

export default function TherapyBooking({ theme, onBookConfirm }: TherapyBookingProps) {
  const [selectedTherapist, setSelectedTherapist] = useState<Counselor | null>(null);
  const [bookingDate, setBookingDate] = useState("2026-05-30");
  const [bookingTime, setBookingTime] = useState("10:00 AM");
  const [preSessionMood, setPreSessionMood] = useState<number>(3); // 1 to 5
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const handleBookSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTherapist) return;

    onBookConfirm(selectedTherapist.name, bookingDate, bookingTime);
    setBookingSuccess(true);
    setTimeout(() => {
      setBookingSuccess(false);
      setSelectedTherapist(null);
    }, 3000);
  };

  return (
    <div className="flex flex-col h-full bg-linear-to-b from-[#FFFDFB] to-stone-50">
      
      {/* Title */}
      <div className="p-4 border-b border-rose-100/30 text-left">
        <h2 className="text-xl font-display font-semibold flex items-center gap-1.5 text-stone-800">
          <Heart className="w-5 h-5 text-rose-400 fill-rose-100" />
          Professional Therapy
        </h2>
        <p className="text-[#8A6F66] text-xs">Certified warm guidance for storm clouds</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        
        {bookingSuccess ? (
          /* BOOKING CONFIRMED SCREEN */
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 animate-fade-in">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center border border-emerald-100 mb-4 animate-bounce">
              <Check className="w-8 h-8" strokeWidth={3} />
            </div>
            <h3 className="text-lg font-display font-bold text-stone-800">Support Session Scheduled</h3>
            <p className="text-xs text-stone-500 max-w-xs mt-2 leading-relaxed">
              Your therapeutic sanctuary with <strong className="text-stone-700">{selectedTherapist?.name}</strong> has been booked successfully for <strong className="text-stone-700">{bookingDate}</strong> at <strong className="text-stone-700">{bookingTime}</strong>.
            </p>
            
            <div className="bg-stone-50 p-4 rounded-2xl border border-stone-100 w-full mt-6 text-left">
              <span className="text-[10px] text-stone-400 uppercase tracking-wider font-bold">Preparation Checklist:</span>
              <p className="text-[11px] text-stone-600 leading-normal mt-1">
                Your pre-session mood was registered. We will prompt you for a post-session check-in to track your emotional relief trajectory. Stay warm!
              </p>
            </div>
          </div>
        ) : !selectedTherapist ? (
          /* THERAPISTS LISTING */
          <div className="flex flex-col gap-4">
            
            {/* Accreditation details */}
            <div className="bg-[#FAF4F0] p-3 rounded-xl border border-rose-100 text-left flex gap-2">
              <Shield className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <p className="text-[10px] text-stone-600 leading-normal">
                All guides on InnerSpace are fully verified Licensed Clinical Social Workers (LCSW) or licensed psychologists trained under highly protective trauma-informed coping protocols. Your privacy is 100% anonymized.
              </p>
            </div>

            <div className="flex flex-col gap-3.5">
              {COUNSELORS.map((counselor) => (
                <div 
                  key={counselor.id}
                  className="bg-white rounded-2xl p-4 border border-rose-100/50 shadow-xs flex flex-col text-left hover:scale-[1.01] transition-transform duration-200"
                >
                  <div className="flex gap-3.5 mb-3">
                    <div className="w-12 h-12 bg-linear-to-b from-[#FFF5F0] to-[#FFE8DE] rounded-full border border-orange-100 flex items-center justify-center text-2xl font-semibold">
                      {counselor.avatarUrl}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-stone-800">{counselor.name}</h3>
                        <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-100 text-amber-600 font-mono text-[9px] font-bold">
                          <Star className="w-3 h-3 fill-current" />
                          <span>{counselor.rating}</span>
                        </div>
                      </div>
                      <p className="text-[10px] text-stone-400 font-sans font-medium mt-0.5">{counselor.role}</p>
                    </div>
                  </div>

                  <p className="text-[11px] text-[#8A6F66] leading-relaxed mb-3 font-sans">
                    {counselor.bio}
                  </p>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {counselor.tags.map(tag => (
                      <span key={tag} className="text-[8px] font-bold bg-stone-100 text-stone-500 px-2 py-0.5 rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between border-t border-dotted border-stone-100/80 pt-3">
                    <span className="text-[10px] text-stone-400">
                      Completed: <strong className="text-stone-700">{counselor.sessionsBooked} sessions</strong>
                    </span>
                    <button
                      onClick={() => setSelectedTherapist(counselor)}
                      className="px-4 py-1.5 bg-gradient-to-r from-orange-300 to-rose-300 text-stone-800 text-xs font-bold rounded-lg shadow-xs hover:scale-105 active:scale-95 transition"
                    >
                      Book Sanctuary
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* ACTIVE APPOINTMENT WORKFLOW PICKER PANEL */
          <form onSubmit={handleBookSession} className="flex flex-col gap-4 text-left">
            <button
              type="button"
              onClick={() => setSelectedTherapist(null)}
              className="text-[11px] text-[#8A6F66] underline mb-1 font-bold"
            >
              ← Back to Therapist Listing
            </button>

            <div className="bg-white/80 p-4 rounded-2xl border border-rose-100 flex items-center gap-3">
              <div className="text-2xl w-10 h-10 bg-[#FAF4F0] rounded-full flex items-center justify-center">
                {selectedTherapist.avatarUrl}
              </div>
              <div>
                <h3 className="text-xs font-bold text-stone-800">Sanctury booking with: {selectedTherapist.name}</h3>
                <span className="text-[10px] text-stone-400">{selectedTherapist.role}</span>
              </div>
            </div>

            <div className="flex flex-col gap-3 bg-white p-4 rounded-2xl border border-rose-100/50">
              <h4 className="text-xs font-bold text-stone-800 mb-1">1. Choose Date & Time</h4>
              
              <div className="grid grid-cols-2 gap-3.5">
                <div>
                  <label className="text-[10px] text-stone-400 block mb-1">Select Date</label>
                  <input
                    type="date"
                    value={bookingDate}
                    onChange={(e) => setBookingDate(e.target.value)}
                    className="w-full text-xs font-mono p-2 bg-stone-50 border border-stone-200 rounded-lg text-stone-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-stone-400 block mb-1">Choose Session Time</label>
                  <select
                    value={bookingTime}
                    onChange={(e) => setBookingTime(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 border border-stone-200 rounded-lg text-stone-700 focus:outline-none"
                  >
                    <option value="09:00 AM">09:00 AM</option>
                    <option value="10:30 AM">10:30 AM</option>
                    <option value="01:00 PM">01:00 PM</option>
                    <option value="03:30 PM">03:30 PM</option>
                    <option value="05:00 PM">05:00 PM</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-3.5 bg-white p-4 rounded-2xl border border-rose-100/50">
              <h4 className="text-xs font-bold text-stone-800">2. Track Mood State Before Session</h4>
              <p className="text-[10px] text-stone-500">
                Helping your therapy guide understand your starting emotional frequency coordinates:
              </p>
              
              <div className="flex justify-between items-center px-1">
                {[
                  { level: 1, label: "Deep overwhelm", face: "😢" },
                  { level: 2, label: "Tense anxiety", face: "🥺" },
                  { level: 3, label: "Muted numbness", face: "😐" },
                  { level: 4, label: "Tender hope", face: "😌" },
                  { level: 5, label: "Warm quiet peace", face: "🌸" }
                ].map((moodItem) => (
                  <button
                    key={moodItem.level}
                    type="button"
                    onClick={() => setPreSessionMood(moodItem.level)}
                    className={`flex flex-col items-center gap-1.5 p-1.5 rounded-xl transition ${
                      preSessionMood === moodItem.level ? "bg-rose-50 border border-rose-200 shadow-xs" : "opacity-60 grayscale"
                    }`}
                  >
                    <span className="text-xl">{moodItem.face}</span>
                    <span className="text-[7px] text-stone-400 max-w-[36px] text-center font-bold">
                      {moodItem.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="py-2.5 w-full bg-linear-to-r from-orange-400 to-rose-300 hover:from-orange-500 hover:to-rose-400 text-white rounded-xl text-xs font-bold shadow-md transition text-center"
            >
              Confirm Scheduled Sanctuary
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
