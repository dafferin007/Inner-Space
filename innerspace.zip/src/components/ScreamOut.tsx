import React, { useState } from "react";
import { AlertCircle, Heart, Flame, Shield, HelpCircle, Send, Sparkles, CloudRain, Check } from "lucide-react";
import { ScreamThought } from "../types";

interface ScreamOutProps {
  theme: any;
  screams: ScreamThought[];
  onAddScream: (text: string) => void;
  onScreamReaction: (screamId: string, reactionType: string) => void;
}

export default function ScreamOut({ theme, screams, onAddScream, onScreamReaction }: ScreamOutProps) {
  const [screamInput, setScreamInput] = useState("");
  const [isAnon, setIsAnon] = useState(true);
  const [activeTab, setActiveTab] = useState<"feed" | "scream">("feed");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [safetyAlert, setSafetyAlert] = useState<{ active: boolean; message: string } | null>(null);
  
  // Custom design style options for the scream post
  const [screamBg, setScreamBg] = useState<"standard" | "twilight" | "amber" | "sage">("standard");

  const handleSubmitScream = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!screamInput.trim()) return;

    setIsSubmitting(true);
    setSafetyAlert(null);

    try {
      // Connect to full-stack safety diagnostic scanner we wrote in server.ts
      const response = await fetch("/api/scream-support", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ screamText: screamInput })
      });
      const data = await response.json();

      if (data.isSafetyAlertTriggered) {
        // Trigger loving, immediately supportive crisis intervention prompts
        setSafetyAlert({
          active: true,
          message: data.comfortMessage || "We hear you deeply. Please know that this heavy cycle does not define your ending. There are soft hands ready to hold you."
        });
      }

      onAddScream(screamInput);
      setScreamInput("");
      setActiveTab("feed");
    } catch (err) {
      console.error(err);
      onAddScream(screamInput);
      setScreamInput("");
      setActiveTab("feed");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-linear-to-b from-stone-50/20 to-neutral-50/40">
      
      {/* Title Header */}
      <div className="p-4 border-b border-rose-100/30 flex items-center justify-between bg-white/40">
        <div>
          <h2 className="text-xl font-display font-semibold flex items-center gap-1.5 text-stone-800">
            <CloudRain className="w-5 h-5 text-rose-400" />
            Scream Out
          </h2>
          <p className="text-[#8A6F66] text-xs">Exhale your heavy weather into silence</p>
        </div>
        
        <div className="flex bg-stone-100/60 rounded-full p-0.5">
          <button
            onClick={() => setActiveTab("feed")}
            className={`px-3 py-1 text-[11px] font-semibold rounded-full transition ${
              activeTab === "feed" ? "bg-white text-stone-800 shadow-xs" : "text-stone-500 opacity-70"
            }`}
          >
            Scream Feed
          </button>
          <button
            onClick={() => setActiveTab("scream")}
            className={`px-3 py-1 text-[11px] font-semibold rounded-full transition ${
              activeTab === "scream" ? "bg-white text-stone-800 shadow-xs" : "text-stone-500 opacity-70"
            }`}
          >
            Release Frustration
          </button>
        </div>
      </div>

      {/* Safety Alert Intervention Section */}
      {safetyAlert && (
        <div className="bg-rose-50 border-y border-rose-300 p-4 animate-pulse relative z-50">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="text-left">
              <h4 className="text-xs font-bold text-rose-900">A Safe Space Holds You Warmly</h4>
              <p className="text-[11px] text-rose-800 leading-normal mt-1 font-sans font-medium">
                {safetyAlert.message}
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <a 
                  href="tel:988" 
                  className="bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold px-3 py-1 rounded-full text-center transition"
                >
                  📞 Call Suicide Prevention Support (988)
                </a>
                <a 
                  href="https://988lifeline.org/chat/" 
                  target="_blank" 
                  className="bg-white border border-rose-300 text-rose-700 text-[10px] font-bold px-3 py-1 rounded-full text-center transition"
                >
                  💬 Live Crisis Chat Website
                </a>
                <button 
                  onClick={() => setSafetyAlert(null)}
                  className="text-[10px] text-rose-500 underline ml-2 hover:text-rose-700"
                >
                  Dismiss quietly
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MAIN CONTAINER CONTENT */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col">
        
        {activeTab === "feed" ? (
          <div className="flex flex-col gap-4 flex-1">
            <div className="bg-slate-100/50 rounded-xl p-3 border border-stone-100/80 mb-1 text-center">
              <p className="text-[11px] text-[#8A6F66] leading-relaxed">
                🌌 Screams are entirely anonymous, releasing heavy burdens. Tap comforting reactions to send warm vibrations. No toxic comments allowed.
              </p>
            </div>

            {screams.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center py-20 text-center opacity-80">
                <div className="w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center mb-3">
                  <CloudRain className="w-6 h-6 text-rose-300 animate-bounce" />
                </div>
                <p className="text-xs text-stone-500 font-medium">The scream space is silent today.</p>
                <button
                  onClick={() => setActiveTab("scream")}
                  className="mt-2 text-xs text-rose-400 font-semibold underline"
                >
                  Be the first to release heavy weather
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {screams.map((scream) => {
                  return (
                    <div
                      key={scream.id}
                      className={`p-4 rounded-2xl shadow-xs border transition-colors ${
                        scream.isCustomBg 
                          ? "bg-gradient-to-tr from-purple-950 to-slate-900 border-purple-800 text-purple-100" 
                          : "bg-white border-rose-100 text-[#5A3E36]"
                      }`}
                    >
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
                          <span className={`text-[10px] uppercase tracking-wider font-bold ${scream.isCustomBg ? "text-purple-300" : "text-stone-400"}`}>
                            Anonymous Soul
                          </span>
                        </div>
                        <span className={`text-[9px] font-mono ${scream.isCustomBg ? "text-slate-400" : "text-stone-400"}`}>
                          {scream.timestamp}
                        </span>
                      </div>

                      <p className="text-xs font-sans leading-relaxed text-left font-medium whitespace-pre-wrap mb-4">
                        {scream.text}
                      </p>

                      {/* Calming reactions pill section */}
                      <div className="border-t border-dotted border-rose-100/60 pt-3 flex flex-wrap gap-1.5 items-center">
                        <span id="label" className="text-[10px] text-stone-400 mr-1.5">Comfort reactions:</span>
                        {[
                          { key: "youMatter", label: "You matter", colors: "bg-rose-50 text-rose-600 hover:bg-rose-100/80" },
                          { key: "sendingWarmth", label: "Sending warmth", colors: "bg-orange-50 text-orange-600 hover:bg-orange-100/80" },
                          { key: "iHearYou", label: "I hear you", colors: "bg-sky-50 text-sky-600 hover:bg-sky-100/80" },
                          { key: "stayWithUs", label: "Stay with us", colors: "bg-emerald-50 text-emerald-600 hover:bg-emerald-100/80" }
                        ].map((btn) => {
                          const count = scream.reactions[btn.key] || 0;
                          return (
                            <button
                              key={btn.key}
                              onClick={() => onScreamReaction(scream.id, btn.key)}
                              className={`px-2.5 py-1 rounded-full text-[9px] font-bold flex items-center gap-1 transition ${btn.colors}`}
                            >
                              <Heart className="w-2.5 h-2.5 fill-current" />
                              <span>{btn.label}</span>
                              <span className="font-mono bg-white/70 px-1 rounded-sm ml-1">{count}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          /* CREATE SCREAM RELEASE INTERACTIVE CONTAINER */
          <form onSubmit={handleSubmitScream} className="flex flex-col gap-4 flex-1">
            <span className="text-xs font-semibold text-[#8A6F66]">Release Your Scream</span>
            <p className="text-left text-[11px] text-stone-500">
              No one will see your avatar, identity, or profile. Let your internal thoughts slip onto this digital static canvas.
            </p>

            <textarea
              value={screamInput}
              onChange={(e) => setScreamInput(e.target.value)}
              placeholder="Scream anything... 'I feel so incredibly burned out by school today.' or 'Why is everything so hollow?'"
              className={`w-full h-44 p-4 rounded-2xl border text-xs font-medium focus:ring-1 focus:ring-rose-200 focus:outline-none leading-relaxed transition ${
                screamBg === "twilight"
                  ? "bg-[#1C162E] text-purple-100 border-purple-800 placeholder-purple-400"
                  : "bg-white text-stone-800 border-rose-100 placeholder-stone-400"
              }`}
            />

            {/* Custom Background selectors to make screams feel like visual stickers */}
            <div className="flex flex-col gap-2">
              <span className="text-[10px] text-stone-500 font-semibold">Visual canvas theme:</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setScreamBg("standard")}
                  className={`px-3 py-1 rounded-lg text-[10px] font-bold border transition ${
                    screamBg === "standard" ? "bg-rose-100 border-rose-300 text-rose-800" : "bg-white border-stone-200 text-stone-600"
                  }`}
                >
                  🍥 Soft Peach
                </button>
                <button
                  type="button"
                  onClick={() => setScreamBg("twilight")}
                  className={`px-3 py-1 rounded-lg text-[10px] font-bold border transition ${
                    screamBg === "twilight" ? "bg-purple-950 border-purple-800 text-purple-200" : "bg-white border-stone-200 text-stone-600"
                  }`}
                >
                  🌌 Cosmic Twilight
                </button>
              </div>
            </div>

            {/* Simulated interactive particle preview info */}
            <div className="bg-orange-50/50 p-3 rounded-xl border border-orange-100 text-left">
              <span className="text-[10px] font-bold text-orange-800 flex items-center gap-1">
                <Shield className="w-3.5 h-3.5 text-orange-500" />
                Moderated Healing Space
              </span>
              <p className="text-[10px] text-orange-700/80 leading-normal mt-0.5">
                Our platform will never tolerate toxic language, bullying, or harsh criticisms. It serves as a soft, comforting sanctuary. If deep distress signs appear, safe resources will automatically deploy for your care.
              </p>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || !screamInput.trim()}
              className="mt-2 py-2 w-full bg-linear-to-r from-orange-400 to-rose-300 hover:from-orange-500 hover:to-rose-400 text-white rounded-xl text-xs font-bold shadow-md transition disabled:opacity-60 flex items-center justify-center gap-1.5"
            >
              {isSubmitting ? (
                <span>Releasing scream into rain...</span>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Scream Anonymously</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
