/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum AppScreen {
  Splash = "SPLASH",
  Auth = "AUTH",
  MoodOnboarding = "MOOD_ONBOARDING",
  Home = "HOME",
  HearOut = "HEAR_OUT",
  ScreamOut = "SCREAM_OUT",
  AnonymousChat = "ANONYMOUS_CHAT",
  TherapyBooking = "THERAPY_BOOKING",
  EmotionalRooms = "EMOTIONAL_ROOMS",
  MoodJournal = "MOOD_JOURNAL",
  MiniGames = "MINI_GAMES",
  UserProfileCustomization = "USER_PROFILE",
  Settings = "SETTINGS"
}

export type ThemePreset = 
  | "peach" 
  | "lavender" 
  | "sage" 
  | "midnight" 
  | "cream"
  | "sunset";

export interface ThemeProperties {
  id: ThemePreset;
  name: string;
  bgColor: string;
  cardColor: string;
  textColor: string;
  accentColor: string;
  glowColor: string;
  buttonBg: string;
  subtextColor: string;
  inputBg: string;
}

export const THEMES: Record<ThemePreset, ThemeProperties> = {
  peach: {
    id: "peach",
    name: "Soft Peach Pink",
    bgColor: "bg-linear-to-b from-[#FFF0ED] via-[#FFE5E0] to-[#FFEDE9]",
    cardColor: "bg-white/60 backdrop-blur-xl border border-white/60 rounded-[32px] shadow-xs text-[#4A3F3D]",
    textColor: "text-[#4A3F3D]",
    accentColor: "[#6D5A57]",
    glowColor: "shadow-[#FFB7B2]/30",
    buttonBg: "bg-[#6D5A57] text-white rounded-full hover:opacity-95 transition-opacity duration-200 shadow-sm",
    subtextColor: "text-[#8E7D7A]",
    inputBg: "bg-white/45 border border-white/60 focus:ring-1 focus:ring-[#FFB7B2] text-stone-700"
  },
  lavender: {
    id: "lavender",
    name: "Lavender Dream",
    bgColor: "bg-linear-to-b from-[#F2EDFF] via-[#EAE1FF] to-[#FAF8FF]",
    cardColor: "bg-white/60 backdrop-blur-xl border border-white/65 rounded-[32px] shadow-xs text-[#3D315B]",
    textColor: "text-[#3D315B]",
    accentColor: "[#56428F]",
    glowColor: "shadow-violet-200/40",
    buttonBg: "bg-[#56428F] text-white rounded-full hover:opacity-95 transition-opacity duration-200 shadow-sm",
    subtextColor: "text-[#786D9B]",
    inputBg: "bg-white/45 border border-white/60 focus:ring-1 focus:ring-violet-300 text-stone-700"
  },
  sage: {
    id: "sage",
    name: "Sage Serenity",
    bgColor: "bg-linear-to-b from-[#F1F7F4] via-[#DEECE4] to-[#F1F6F3]",
    cardColor: "bg-white/60 backdrop-blur-xl border border-white/65 rounded-[32px] shadow-xs text-[#2E3D30]",
    textColor: "text-[#2E3D30]",
    accentColor: "[#3C5A41]",
    glowColor: "shadow-emerald-200/40",
    buttonBg: "bg-[#3C5A41] text-white rounded-full hover:opacity-95 transition-opacity duration-200 shadow-sm",
    subtextColor: "text-[#627D66]",
    inputBg: "bg-white/45 border border-white/60 focus:ring-1 focus:ring-emerald-300 text-stone-700"
  },
  midnight: {
    id: "midnight",
    name: "Midnight Cosmic",
    bgColor: "bg-linear-to-b from-[#161B2E] via-[#0E1220] to-[#0A0D18]",
    cardColor: "bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-[32px] shadow-xs text-[#E2E8F0]",
    textColor: "text-[#E2E8F0]",
    accentColor: "[#0EA5E9]",
    glowColor: "shadow-cyan-950/40",
    buttonBg: "bg-slate-800 text-white rounded-full hover:opacity-95 transition-opacity duration-200 shadow-sm border border-slate-700",
    subtextColor: "text-[#94A3B8]",
    inputBg: "bg-slate-950/45 border border-white/10 focus:ring-1 focus:ring-cyan-500 text-slate-100"
  },
  cream: {
    id: "cream",
    name: "Warm Cream",
    bgColor: "bg-linear-to-b from-[#FCFAF2] via-[#EFE6CE] to-[#FDFBF7]",
    cardColor: "bg-white/60 backdrop-blur-xl border border-white/65 rounded-[32px] shadow-xs text-[#4A3B2C]",
    textColor: "text-[#4A3B2C]",
    accentColor: "[#7D6B5A]",
    glowColor: "shadow-amber-200/30",
    buttonBg: "bg-[#7D6B5A] text-white rounded-full hover:opacity-95 transition-opacity duration-200 shadow-sm",
    subtextColor: "text-[#8F7E6F]",
    inputBg: "bg-white/45 border border-white/60 focus:ring-1 focus:ring-amber-300 text-stone-700"
  },
  sunset: {
    id: "sunset",
    name: "Sunset Warmth",
    bgColor: "bg-linear-to-b from-[#FFF2E0] via-[#FFE2C5] to-[#FFF7EE]",
    cardColor: "bg-white/60 backdrop-blur-xl border border-white/65 rounded-[32px] shadow-xs text-[#6B371F]",
    textColor: "text-[#6B371F]",
    accentColor: "[#9C5331]",
    glowColor: "shadow-orange-200/40",
    buttonBg: "bg-[#9C5331] text-white rounded-full hover:opacity-95 transition-opacity duration-200 shadow-sm",
    subtextColor: "text-[#A36D56]",
    inputBg: "bg-white/45 border border-white/60 focus:ring-1 focus:ring-orange-300 text-stone-700"
  }
};

export interface AestheticAvatar {
  id: string;
  name: string;
  svgHtml: string;
  auraColor: string;
}

export const AESTHETIC_AVATARS: AestheticAvatar[] = [
  {
    id: "glowing-mask",
    name: "Glowing Mask",
    svgHtml: `<g transform="translate(10,10) scale(0.8)"><circle cx="50" cy="50" r="40" fill="url(#maskGlow)" /><rect x="40" y="32" width="20" height="26" rx="10" fill="#fff" opacity="0.9" /><ellipse cx="46" cy="42" rx="3" ry="1.5" fill="#3D315B" /><ellipse cx="54" cy="42" rx="3" ry="1.5" fill="#3D315B" /><path d="M 47 49 Q 50 51 53 49" stroke="#3D315B" stroke-width="1.5" fill="none" stroke-linecap="round" /></g>`,
    auraColor: "rgba(255, 187, 150, 0.6)"
  },
  {
    id: "anime-silhouette",
    name: "Anime Silhouette",
    svgHtml: `<g transform="translate(10,10) scale(0.8)"><circle cx="50" cy="50" r="40" fill="#0D1527" /><path d="M 50 20 L 58 35 L 53 33 L 56 45 L 44 45 L 47 33 L 42 35 Z" fill="#FFCBB5" /><path d="M 30 55 C 30 45, 70 45, 70 55 C 70 65, 30 65, 30 55 Z" fill="#F1ECE9" opacity="0.3" /><path d="M 50 20 Q 38 25, 38 35 Q 40 40, 50 48 Q 60 40, 62 35 Q 62 25, 50 20" fill="none" stroke="#fff" stroke-width="2" /></g>`,
    auraColor: "rgba(186, 215, 233, 0.6)"
  },
  {
    id: "cloud-spirit",
    name: "Dreamy Cloud",
    svgHtml: `<g transform="translate(10,10) scale(0.8)"><path d="M30 60 c-10 0-18-8-18-18 c0-9 7-16 16-18 c2-10 10-18 20-18 c9 0 17 6 20 14 c5-4 11-6 17-6 c11 0 20 9 20 20 c0 11-9 20-20 20 z" fill="url(#cloudGrad)" /><circle cx="40" cy="45" r="2.5" fill="#5F6F81" /><circle cx="60" cy="45" r="2.5" fill="#5F6F81" /><path d="M 46 51 Q 50 54 54 51" stroke="#5F6F81" stroke-width="2" fill="none" stroke-linecap="round" /></g>`,
    auraColor: "rgba(178, 235, 242, 0.7)"
  },
  {
    id: "starry-night",
    name: "Golden Star",
    svgHtml: `<g transform="translate(10,10) scale(0.8)"><circle cx="50" cy="50" r="40" fill="url(#starGlow)" /><path d="M 50 15 L 58 35 L 80 38 L 62 52 L 68 74 L 50 62 L 32 74 L 38 52 L 20 38 L 42 35 Z" fill="#FFE082" /><circle cx="44" cy="43" r="2" fill="#5D4037" /><circle cx="56" cy="43" r="2" fill="#5D4037" /><path d="M 48 48 Q 50 50 52 48" stroke="#5D4037" stroke-width="1.5" fill="none" stroke-linecap="round" /></g>`,
    auraColor: "rgba(255, 213, 79, 0.6)"
  },
  {
    id: "abstract-spirit",
    name: "Healing Aura",
    svgHtml: `<g transform="translate(10,10) scale(0.8)"><circle cx="50" cy="50" r="42" fill="none" stroke="url(#auraGrad)" stroke-width="4" stroke-dasharray="10, 5" /><circle cx="50" cy="50" r="30" fill="url(#pureLight)" /><circle cx="45" cy="48" r="1.5" fill="#607D8B" /><circle cx="55" cy="48" r="1.5" fill="#607D8B" /><path d="M 47 53 Q 50 55 53 53" stroke="#607D8B" stroke-width="1" fill="none" /></g>`,
    auraColor: "rgba(200, 230, 201, 0.7)"
  },
  {
    id: "dreamy-flower",
    name: "Sun Sunflower",
    svgHtml: `<g transform="translate(10,10) scale(0.8)"><circle cx="50" cy="50" r="18" fill="#5D4037" /><g id="petals"><path d="M50 15 C52 25, 48 25, 50 15 Z" fill="#FBC02D" /><path d="M50 85 C52 75, 48 75, 50 85 Z" fill="#FBC02D" /><path d="M15 50 C25 52, 25 48, 15 50 Z" fill="#FBC02D" /><path d="M85 50 C75 52, 75 48, 85 50 Z" fill="#FBC02D" /><path d="M25 25 C35 32, 32 35, 25 25 Z" fill="#FBC02D" /><path d="M75 75 C65 68, 68 65, 75 75 Z" fill="#FBC02D" /><path d="M25 75 C32 65, 35 68, 25 75 Z" fill="#FBC02D" /><path d="M75 25 C68 35, 65 32, 75 25 Z" fill="#FBC02D" /></g><circle cx="45" cy="48" r="1.5" fill="#fff" /><circle cx="55" cy="48" r="1.5" fill="#fff" /></g>`,
    auraColor: "rgba(255, 245, 157, 0.7)"
  }
];

export const CREATIVE_NAMES = [
  "moonchild.exe",
  "sleepy_ghost",
  "pinkvoid",
  "echo.within",
  "lonelysunflower",
  "pastel_cloud",
  "midnight_tea",
  "gentle_breeze",
  "silent_echo",
  "starlight_spirit"
];

export interface Counselor {
  id: string;
  name: string;
  role: string;
  rating: number;
  tags: string[];
  bio: string;
  isAvailable: boolean;
  avatarUrl: string;
  sessionsBooked: number;
}

export const COUNSELORS: Counselor[] = [
  {
    id: "counselor-1",
    name: "Dr. Evelyn Rowan",
    role: "LMSW, Trauma & Grief Therapy",
    rating: 4.9,
    tags: ["Anxiety", "Trauma Recovery", "Gentle Listener"],
    bio: "Focused on creating a safe warm cradle for anxious minds to softly unpack complex storms. Interactive meditation focus.",
    isAvailable: true,
    avatarUrl: "👩‍⚕️",
    sessionsBooked: 243
  },
  {
    id: "counselor-2",
    name: "Julian Woods",
    role: "Emotional Guide & Art Therapy",
    rating: 4.8,
    tags: ["Burnout", "Self-Expression", "Anxiety"],
    bio: "Helping individuals channel unspoken heavy emotions into serene visual art, abstract journals, and physical anchoring.",
    isAvailable: true,
    avatarUrl: "👨‍🎨",
    sessionsBooked: 198
  },
  {
    id: "counselor-3",
    name: "Sena Kim",
    role: "Clinical Psychologist & CBT Specialist",
    rating: 5.0,
    tags: ["Depression", "Coping Tactics", "Safe Attachment"],
    bio: "Guiding young adults through overwhelming periods of transition, self-doubt, isolation, or relational disconnect.",
    isAvailable: false,
    avatarUrl: "👩‍💼",
    sessionsBooked: 352
  }
];

export interface ScreamThought {
  id: string;
  text: string;
  screamType: "text" | "voice" | "bubble";
  reactions: Record<string, number>;
  timestamp: string;
  username: string;
  avatarId: string;
  isCustomBg?: boolean;
}

export interface SupportRoom {
  id: string;
  name: string;
  sentiment: string;
  emoji: string;
  color: string;
  ambientSound: string;
  userCount: number;
  description: string;
}

export const SUPPORT_ROOMS: SupportRoom[] = [
  {
    id: "room-lonely",
    name: "The Quiet Hearth",
    sentiment: "lonely",
    emoji: "🕯️",
    color: "from-orange-100 to-amber-50 dark:from-amber-950/20 dark:to-slate-900",
    ambientSound: "Soft Fire Crackle",
    userCount: 14,
    description: "A room for those who feel disconnected. Sit by the virtual candle, stay silent or type sweet things."
  },
  {
    id: "room-overthinking",
    name: "The Cloud Library",
    sentiment: "overthinking",
    emoji: "☁️",
    color: "from-blue-50 to-blue-100/30 dark:from-indigo-950/20 dark:to-slate-900",
    ambientSound: "Soft Rain & Classical",
    userCount: 22,
    description: "Let your spinning thoughts drift like slow white clouds. Share what is pacing in your cerebral orbits."
  },
  {
    id: "room-heartbreak",
    name: "The Rainy Sanctuary",
    sentiment: "heartbreak",
    emoji: "🌧️",
    color: "from-rose-50 to-rose-100/20 dark:from-pink-950/20 dark:to-slate-900",
    ambientSound: "Forest Thunderstorm",
    userCount: 9,
    description: "Hold your tender, pieces in this space. No judgement - just validation, warm tears, and quiet solace."
  },
  {
    id: "room-burnout",
    name: "The Soft Moss Meadow",
    sentiment: "burnout",
    emoji: "🌿",
    color: "from-[#F2F6F3] to-[#DFEDE2] dark:from-emerald-950/20 dark:to-slate-900",
    ambientSound: "Meadow Birds & Wind",
    userCount: 18,
    description: "You have run so fast. Lay your defenses in the grass. Take a full, deep sigh with others resting."
  }
];

export interface ChatMessage {
  id: string;
  sender: "user" | "counselor" | "listener" | "system";
  text: string;
  timestamp: string;
  avatarId?: string;
}

export interface JournalEntry {
  id: string;
  date: string;
  moodLevel: number; // 1 to 5
  sticker: string;
  note: string;
  doodleDataUrl?: string;
  auraDescription?: string;
  auraColor?: string;
}
